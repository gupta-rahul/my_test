#include<linux/init.h>		
#include<linux/module.h>	
#include<linux/sched.h>
#include<linux/cdev.h>
#include<linux/uaccess.h>
#include<linux/device.h>
#include<linux/fs.h>
#include<linux/ioctl.h>
#include<linux/highmem.h>

MODULE_LICENSE("Dual BSD/GPL");

#define FIRST_MINOR	15
#define NO_DEV	5

int my_open (struct inode *inode, struct file *filep);
int my_close(struct inode *inode, struct file *filep);
long my_ioctl(struct file *filep, unsigned int pid, unsigned long variable);
static int my_init(void);
static void my_exit(void);
struct task_struct *task;

struct file_operations fops = {
	.owner = THIS_MODULE,
	.open = my_open,
	.unlocked_ioctl = my_ioctl,
	.release = my_close,
};

char *device_name = "char_dd";	/* Contain Device Name */
int major_no;	
static dev_t my_dev;	/* hold major & minor number */	
struct cdev *my_cdev;	/*character device driver descriptor */

/* Class & Device Structue */
static struct class *mychar_class;
static struct device *mychar_device;

/* ioctl Function */
long my_ioctl(struct file *filep, unsigned int pid, unsigned long variable)
{
	pgd_t *pgd_add;
	int *temp_ptr = NULL;	
	int *temp_ptr1 = NULL;
	int *temp_ptr2 = NULL;
	unsigned int start_10_bit;
	unsigned int next_10_bit;
	unsigned int last_12_bit;
	struct pid *proc_id = NULL;

	start_10_bit = (unsigned)variable  >> 22;
	next_10_bit = (variable >> 12) & 0x000003ff;
	last_12_bit = variable & 0x00000fff;

	printk(KERN_INFO " start_10_bit:- %x\nnext_10_bit:- %x\nlast_12_bit:- %x\n",start_10_bit,next_10_bit,last_12_bit);
	
	printk(KERN_INFO "IOCTL FUCNTION : PID - %d\n", pid);
	
	proc_id = find_get_pid(pid);
	
	task = pid_task(proc_id, PIDTYPE_PID);

	pgd_add = task->mm->pgd;
	
	printk(KERN_INFO " Variable address:- 0x%x\n", variable);
	
	printk(KERN_INFO " Pgd Address :-0x %08x\n", pgd_add);

	printk(KERN_INFO " virtual Index Address:- 0x%08x \n\n", ((int *)pgd_add + start_10_bit));

	printk(KERN_INFO " Physical Address of PGD:- %x\n\n", *(pgd_add + start_10_bit));

//	printk(KERN_INFO " Physical Address  PGD MEMBER:- %x\n\n", ((int *)pgd_add + start_10_bit)->pgd);

//	if ((*((int *)pgd_add + start_10_bit)) < 0x38000000) {
//		printk(KERN_INFO "if part is Executiing...\n");
//		temp_ptr = (*((int *)pgd_add + start_10_bit)) + 0xc0000000;
//	} else { 
		temp_ptr = kmap(&(mem_map[(*((int *)pgd_add + start_10_bit)) >> 12 ]));
//	}

	printk(KERN_INFO "Kernel_virtual_Base_Address_PT:- %0x\n", temp_ptr);
	printk(KERN_INFO "Kernel_virtual_inde_Address_PT:- %0x\n", temp_ptr + next_10_bit);

	printk(KERN_INFO "Physical Address of PT:- 0x%0x\n", *(temp_ptr + next_10_bit));

	if ((*(temp_ptr + next_10_bit)) < 0x38000000) {
            printk(KERN_INFO "if part is Executiing...\n");
             temp_ptr1 = (*(temp_ptr + next_10_bit)) + 0xc0000000;
         } else {
		temp_ptr1 = kmap(&(mem_map[(*(temp_ptr + next_10_bit)) >> 12 ]));
	}

	printk(KERN_INFO "virtual_Base_Pageframe:- %0x\n", temp_ptr1);
	printk(KERN_INFO "virtual_index_pafeFrame:- %x\n", temp_ptr1 + last_12_bit);
		
	printk(KERN_INFO "value:- %d\n", *(temp_ptr1 + last_12_bit));

	/*if ((*(temp_ptr1 + last_12_bit)) < 0x38000000) {
                 printk(KERN_INFO "2nd if part is Executiing...\n");
                 temp_ptr2 = (*(temp_ptr1 + last_12_bit)) + 0xc0000000;
         } else {
		temp_ptr2 = kmap(&(mem_map[(*(temp_ptr1 + last_12_bit)) >> 12]));
	}
*/

//	printk(KERN_INFO " Physical Address 2 :- %x\n\n", (*(pgd_add + start_10_bit))   next_10_bit);
/*
	for( i = 0; i < 1024; i++) {
	if ((task->mm)->pgd) 
	printk(KERN_INFO "phy:- %x\n", *(task->mm->pgd));
	(task->mm)->pgd++;
	
	}*/

	return 0;
}


/* open Funtion */
int my_open (struct inode *inode, struct file *filep)
{
	printk(KERN_INFO "OPEN SUCCESSFULL\n");
	
	return 0;
}

/* Close Funtion */
int my_close(struct inode *inode, struct file *filep)
{
	printk(KERN_INFO "CLOSE SUCCESSFULL\n");
	return 0;
}

static int __init my_init(void)
{
	int status;

	printk(KERN_INFO "Starting Character Device \n");

	/*Allocating Device Number */

	status = alloc_chrdev_region(&my_dev,FIRST_MINOR, NO_DEV, device_name);
	if (status < 0 ) {
		printk(KERN_INFO "Device Number allocation failed: %d\n", status);
	}

	printk(KERN_INFO "Major Number :-%d\t Minor Number :- %d\n", MAJOR(my_dev), MINOR(my_dev));

	/* Allocation Memory for my_CDEV*/
	my_cdev = cdev_alloc();
	if (my_cdev == NULL) {
		printk(KERN_INFO "Cdev Allocation Failed\n");
	}


	/* Initialization of CDEV with file_operation fops*/
	cdev_init(my_cdev, &fops);
	my_cdev->owner = THIS_MODULE;

	/* Adding my_cdev to the List */
	status = cdev_add(my_cdev,my_dev, NO_DEV);
	if (status) {
		printk(KERN_INFO "Cdev Add Failed\n");
	}

	/* Create a class & an entry in sysfs */
	mychar_class = class_create(THIS_MODULE, device_name);
	if (IS_ERR(mychar_class)) {
		printk(KERN_INFO " Class creation failed \n");
	}

	/* Create mychar_device in sysfs and an device entry will be made in dev directory */

	mychar_device = device_create(mychar_class, NULL, my_dev, NULL, device_name);

	if (IS_ERR(mychar_device)) {
		printk(KERN_INFO "device created filed \n");
	}

	return 0;
}

static void my_exit(void)
{
	printk(KERN_INFO "EXITING THE CHAR DRIVER\n");
	device_destroy(mychar_class, my_dev);
	class_destroy(mychar_class);
	cdev_del(my_cdev);
	unregister_chrdev_region(my_dev, NO_DEV);
}

module_init(my_init);
module_exit(my_exit);
