#include<stdio.h>
#include<fcntl.h>
#include<linux/ioctl.h>
#include <sys/mman.h>

int a = 200;

int main(void)
{
 	int i;
	int fd;
	char uBuffer[100];// = "character_device_driver";
	
	void *vga_buf = NULL;

         fd = open("/dev/char_dd", O_RDWR);
         if(fd < 0)
                 perror("Unable to open the device");
         else
                printf("File open successful : - %d\n", fd);

	printf("Address of a:- %p\n", &a); 
	printf("Value of a before IOCTL :- %d\n", a);

        printf("App Pid:- %d\n", getpid());
	
	vga_buf = mmap(0, 256*1024*1024, PROT_WRITE | PROT_READ, MAP_SHARED , fd , 0);

	printf("vga_buf : --0x%08x\n", vga_buf);

	for (i = 0; i < (256*1024*1024) ; i++) {
		*((char *)(vga_buf)) = 2;
		vga_buf++;
	}

	printf("Value of a after IOCTL :- %d\n", a);
         close(fd);

         return 0;
}
