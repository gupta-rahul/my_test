#include<linux/init.h>		
#include<linux/module.h>	
#include<linux/sched.h>
#include<linux/cdev.h>
#include<linux/uaccess.h>
#include<linux/device.h>
#include<linux/fs.h>
#include<linux/ioctl.h>
#include<linux/highmem.h>
#include <linux/mman.h>

MODULE_LICENSE("Dual BSD/GPL");

#define FIRST_MINOR	15
#define NO_DEV	5

int my_open (struct inode *inode, struct file *filep);
int my_close(struct inode *inode, struct file *filep);
long my_ioctl(struct file *filep, unsigned int pid, unsigned long variable);
int my_mmap(struct file *filep, struct vm_area_struct *vm);

static int my_init(void);
static void my_exit(void);
struct task_struct *task;

struct file_operations fops = {
	.owner = THIS_MODULE,
	.open = my_open,
//	.unlocked_ioctl = my_ioctl,
	.mmap = my_mmap,
	.release = my_close,
};

char *device_name = "char_dd";	/* Contain Device Name */
int major_no;	
static dev_t my_dev;	/* hold major & minor number */	
struct cdev *my_cdev;	/*character device driver descriptor */

/* Class & Device Structue */
static struct class *mychar_class;
static struct device *mychar_device;

/* mmap function */
int my_mmap(struct file *filep, struct vm_area_struct *vm)
{
	int res;
	res = remap_pfn_range(vm, vm->vm_start, (0xe0000000 >> 12), vm->vm_end - vm->vm_start, vm->vm_page_prot);
	printk(KERN_INFO "value of Result:- %d\n", res);
	return 0;	
}

/* open Funtion */
int my_open (struct inode *inode, struct file *filep)
{
	printk(KERN_INFO "OPEN SUCCESSFULL\n");
	
	return 0;
}

/* Close Funtion */
int my_close(struct inode *inode, struct file *filep)
{
	printk(KERN_INFO "CLOSE SUCCESSFULL\n");
	return 0;
}

static int __init my_init(void)
{
	int status;

	printk(KERN_INFO "Starting Character Device \n");

	/*Allocating Device Number */

	status = alloc_chrdev_region(&my_dev,FIRST_MINOR, NO_DEV, device_name);
	if (status < 0 ) {
		printk(KERN_INFO "Device Number allocation failed: %d\n", status);
	}

	printk(KERN_INFO "Major Number :-%d\t Minor Number :- %d\n", MAJOR(my_dev), MINOR(my_dev));

	/* Allocation Memory for my_CDEV*/
	my_cdev = cdev_alloc();
	if (my_cdev == NULL) {
		printk(KERN_INFO "Cdev Allocation Failed\n");
	}


	/* Initialization of CDEV with file_operation fops*/
	cdev_init(my_cdev, &fops);
	my_cdev->owner = THIS_MODULE;

	/* Adding my_cdev to the List */
	status = cdev_add(my_cdev,my_dev, NO_DEV);
	if (status) {
		printk(KERN_INFO "Cdev Add Failed\n");
	}

	/* Create a class & an entry in sysfs */
	mychar_class = class_create(THIS_MODULE, device_name);
	if (IS_ERR(mychar_class)) {
		printk(KERN_INFO " Class creation failed \n");
	}

	/* Create mychar_device in sysfs and an device entry will be made in dev directory */

	mychar_device = device_create(mychar_class, NULL, my_dev, NULL, device_name);

	if (IS_ERR(mychar_device)) {
		printk(KERN_INFO "device created filed \n");
	}

	return 0;
}

static void my_exit(void)
{
	printk(KERN_INFO "EXITING THE CHAR DRIVER\n");
	device_destroy(mychar_class, my_dev);
	class_destroy(mychar_class);
	cdev_del(my_cdev);
	unregister_chrdev_region(my_dev, NO_DEV);
}

module_init(my_init);
module_exit(my_exit);
