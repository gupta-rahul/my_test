#include<stdio.h>
#include<fcntl.h>
#include<linux/ioctl.h>


int a = 200;

int main(void)
{
//int a = 100;
 	int fd;
	char uBuffer[100];// = "character_device_driver";

         fd = open("/dev/char_dd", O_RDWR);
         if(fd < 0)
                 perror("Unable to open the device");
         else
                printf("File open successful : - %d\n", fd);

	printf("Address of a:- %p\n", &a); 
	printf("Value of a before IOCTL :- %d\n", a);

        printf("App Pid:- %d\n", getpid());

	if (ioctl(fd, getpid(), &a) == -1) {
      	perror("query_apps ioctl get");
	}

	printf("Value of a after IOCTL :- %d\n", a);
         close(fd);

         return 0;
}
