#ifndef _BST_H_
#define _BST_H_

#include<stdio.h>
#include<stdlib.h>

struct bst {					/* BST Structure */
	struct bst *left_child;
	struct bst *right_child;
	int info;
};


int insert_node(struct bst **root);		/* Function for Inserting the node in BST*/

int display_inorder(struct bst **root);		/* Function for Displaying BST in Inorder */

int display_preorder(struct bst **root);	/* Function for Displaying BST in Preorder */

int display_postorder(struct bst **root);	/* Function for Displaying BST in Postorder */

int max_min(struct bst **root, int opt);	/* Function for Finding Max & Min in BST */

int search(struct bst **root);			/* Function for Searching in BST */

int delete_node(struct bst **root);		/* Function for Deleting node in BST */

int display_option(struct bst **root);		/* Function for Display Option */
#endif
