#include<bst.h>

int max_min(struct bst **root, int opt)
{

        struct bst *temp_ptr = NULL;                    /* pointer of Struct bst type */
        struct bst *temp_parent = NULL;                    /* pointer of Struct bst type */
	
	temp_ptr = *root;

	if (temp_ptr == NULL) {
        	printf("Binary Search Tree is Empty\n");
		return 0;
        }

	if (opt == 1) {					/* Maximum number in BST */
		while (temp_ptr != NULL) {
			temp_parent = temp_ptr;
			temp_ptr = temp_ptr->right_child;
		}
		printf("Maximum value :- %d\n", temp_parent->info);
	} else {					/* Minimum Number in BST */
		while (temp_ptr != NULL) {
			temp_parent = temp_ptr;
                        temp_ptr = temp_ptr->left_child;
                }
                printf("Minimum value :- %d\n", temp_parent->info);
	}
	
	return 0;
} 
