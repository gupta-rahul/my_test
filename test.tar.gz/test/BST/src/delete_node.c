/*
   Funtion for Inserting Node in Binary Search tree
 */

#include<bst.h>

int delete_node(struct bst **root)
{

	int item;

	int flag = 0;
	struct bst *temp_ptr1 = NULL;			/* pointer of Struct bst type */
	struct bst *temp_ptr = NULL;			/* pointer of Struct bst type */
	struct bst *temp_parent = NULL;			/* pointer of Struct bst type */
	struct bst *temp_parent1 = NULL;		/* pointer of Struct bst type */
	struct bst *child = NULL;			/* pointer of Struct bst type */

	/* Checking whether the BST is created or Not */	
	if (*root == NULL) {
		printf("---->Binary Search Tree is Empty\n\n");
		return 0;
	}

	printf("Enter the Item to Delete\n");
	scanf("%d", &item);

	temp_ptr = *root;

	/* inserting node in BST */
	while (temp_ptr != NULL) {
		if (temp_ptr->info == item) {
			flag = 1;	
			break;	
		}	
		temp_parent = temp_ptr;
		if (temp_ptr->info > item)
			temp_ptr = temp_ptr->left_child;
		else if (temp_ptr->info < item)
			temp_ptr = temp_ptr->right_child;
	}

	if (flag == 0) {
		printf("Element Not Found\n");
		return 0;
	}

	/************** if Node has No Child ********************/
	if (temp_parent == NULL) {			/* Root Node */
		if( (temp_ptr->left_child == NULL) && (temp_ptr->right_child == NULL)) {
			free(*root);
			*root = NULL;
			return 0;
		}
	} else {
		if( (temp_ptr->left_child == NULL) && (temp_ptr->right_child == NULL)) {
			if (temp_parent->left_child == temp_ptr) 
				temp_parent->left_child = NULL;
			else
				temp_parent->right_child = NULL;
			free(temp_ptr);
			return 0;
		}
	}

	/************** if Node has two Child *********************/

	if ((temp_ptr->left_child != NULL) && (temp_ptr->right_child != NULL)) {
		temp_parent1 = temp_ptr;
		temp_ptr1 = temp_ptr->right_child;

	/* finding next inorder successor */
		while (temp_ptr1->left_child != NULL) {
			temp_parent1 = temp_ptr1;
			temp_ptr1 = temp_ptr1->left_child;
		}

	/* Copying the succesor to node to be deleted */	
		temp_ptr->info = temp_ptr1->info;

		if (temp_ptr1->right_child != NULL)  {	/* If one child node */
			if (temp_parent1->right_child == temp_ptr1)
				temp_parent1->right_child = temp_ptr1->right_child;
			else
				temp_parent1->left_child = temp_ptr1->right_child; 
		} else {
			if (temp_parent1->right_child == temp_ptr1)
				temp_parent1->right_child = NULL;
			else if (temp_parent1->left_child == temp_ptr1)
				temp_parent1->left_child = NULL;
		}

		return 0;
	}

	/******************** If Node has One Child **********************/
	if (temp_ptr->left_child != NULL) {
                child = temp_ptr->left_child;
        } else if (temp_ptr->right_child != NULL) {
                child = temp_ptr->right_child;
        }
        if (temp_parent == NULL) {                      /* Root Node */
        	*root = child;
                return 0;
        } else {
        	if (temp_parent->left_child == temp_ptr)
                	temp_parent->left_child = child;
                else
                        temp_parent->right_child = child;
                        return 0;
        }
	
	if (flag == 0)
		printf("Element Not Found\n");
	return 0;
}
