#include<bst.h>

int main(void)
{
        struct bst *root = NULL;

        int choice = 0;	
	int max = 1;
	int min = 2;

        while (1) {
        printf("\tBinary Search Tree\n");
        printf("1. Insert operations in BST\n");
        printf("2. Delete operations in BST\n");
        printf("3. Search Element in BST\n");
        printf("4. Maximum Element in BST\n");
        printf("5. Minimum Element in BST\n");
        printf("6. Display operationsin BST\n");
	printf("7. Exit \n");
        printf("Enter Choice\n");

        scanf("%d", &choice);

        switch(choice) {

        case 1:	insert_node(&root);
                break;

        case 2:	delete_node(&root);
                break;

        case 3:	search(&root);
                break;

        case 4: max_min(&root, max);
                break;

        case 5: max_min(&root, min);
                break;
        
	case 6:	display_option(&root);
                break;

        case 7: exit(1);
	
	
	}

	}

	return 0;

}
