/*
	Funtion for Inserting Node in Binary Search tree
*/

#include<bst.h>

int insert_node(struct bst **root)
{

	struct bst *temp_ptr = NULL;			/* pointer of Struct bst type */
	struct bst *temp_bst = NULL;			/* pointer of Struct bst type */
	struct bst *temp_parent = NULL;			/* pointer of Struct bst type */
	
	/* Memory Allocation */
	if ((temp_bst = (struct bst *)malloc(sizeof(struct bst))) == NULL)
		printf("---->Memory Allocation faile in Create_bst funtion\n");

	temp_ptr = *root;
	
	/* getting the node Value */
enter:	printf("Enter the Element\n");
	scanf("%d", &temp_bst->info);

        temp_bst->left_child = NULL;
        temp_bst->right_child = NULL;
	
        /* Checking whether the BST is created or Not */
        if (temp_ptr == NULL) {
		*root = temp_bst;
		printf("Root is creating\n");
		return 0;
        } else {
		/* inserting node in BST */
			while (temp_ptr != NULL) {
				temp_parent = temp_ptr;
	
				if (temp_ptr->info > temp_bst->info)
					temp_ptr = temp_ptr->left_child;
				else if (temp_ptr->info < temp_bst->info)
					temp_ptr = temp_ptr->right_child;
				else { 	
					printf("\n---->Duplicate Value\n---->Please Re-Enter the Value\n");
					temp_ptr = *root;
					goto enter;
				}
			}
	/* Inserting node & printing Parent Value */
		if (temp_parent->info > temp_bst->info) {
			printf("Adding as Left child of Node %d\n", temp_parent->info);
			temp_parent->left_child = temp_bst;
		} else if (temp_parent->info < temp_bst->info) {
			printf("Adding as Right child of Node %d\n", temp_parent->info);
			temp_parent->right_child = temp_bst;
		}
	}
	
	return 0;
}
