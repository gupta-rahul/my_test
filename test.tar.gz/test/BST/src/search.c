#include<bst.h>

int search(struct bst **root)
{
		
	int flag = 0;
       	int item;
	 struct bst *temp_ptr = NULL;                    /* pointer of Struct bst type */
	
	temp_ptr = *root;

	if (temp_ptr == NULL) {
        	printf("Binary Search Tree is Empty\n");
		return 0;
        }
	
	printf("Enter the Element to search\n");
	scanf("%d", &item);

       /* inserting node in BST */
        while (temp_ptr != NULL) {
                if (temp_ptr->info > item)
                        temp_ptr = temp_ptr->left_child;
                else if (temp_ptr->info < item)
                        temp_ptr = temp_ptr->right_child;
                else {
                        printf("\n---->Element Found\n");
			flag = 1;
			break;
	        }
        }

	if (flag == 0)
		printf("Element Not Found\n");

	return 0;
} 
