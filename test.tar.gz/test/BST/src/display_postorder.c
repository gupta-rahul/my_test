/*
	Funtion for Displaying Binary Search tree in postorder
*/

#include<bst.h>

int display_postorder(struct bst **root)
{

	struct bst *temp_ptr = NULL;			/* pointer of Struct bst type */
	
	/* Checking whether the BST is created or Not */	
	if (*root == NULL) {
		return 0;
	}
	
	temp_ptr = *root;
		
	display_postorder(&temp_ptr->left_child);
	display_postorder(&temp_ptr->right_child);
	printf("Item:- %d\n", temp_ptr->info);
	return 0;
}
