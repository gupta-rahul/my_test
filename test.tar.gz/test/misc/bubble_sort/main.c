#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int i;
	int j;
	int k = 0;
	int pos;
	int temp;
	int arr[50];
	int size;
	
	printf("Enter the Enter the Number of Elements want to Entere \n");
	scanf("%d", &size);
	
	printf("Enter the Elements\n");
	for (i = 0; i < size; i++) {
		scanf("%d", &arr[i]);
	}
	
	printf("\nEntered Elements are:- ");
	for (i = 0; i < size; i++) {
		printf("%d\t", arr[i]);
	}
	printf("\n");
	
	for (i = 0; i < size; i++) {
		for(j = 0; j < (size -i) ; j++) {
			for ( k = j + 1; k < (size - i); k++) {
				if (arr[j] > arr[k]) {
					temp = arr[j];
					arr[j] = arr[k];
					arr[k] = temp;
				}
			}
		}
	}
	
	printf("\nSorted Elements are:- ");
	for (i = 0; i < size; i++) {
		printf("%d\t", arr[i]);
	}
	
	printf("\n");

	return 0;
}
