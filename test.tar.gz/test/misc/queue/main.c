#include<stdio.h>
#include<stdlib.h>


struct node {
	struct node * next;
	int info;
};

void display();
void insert();
void remov();
	
struct node *start = NULL;

int main()
{
	int choice;


	while (1) {
	
	printf("Enter your Choice \n");
	printf("1. INSERT \n");
	printf("2. DELETE \n");
	printf("3. Display\n");
	printf("4. Exit\n");
	scanf("%d", &choice);
	

	switch (choice) {
		case 1: insert();
			break;	
		case 2: remov();
			break;	

		case 3: display();
			break;	

		case 4: exit(0);
			break;	
	}
	
	}
	return 0;
}



void insert()
{
	int item;
	struct node *temp_ptr = NULL;
	struct node *temp = NULL;

	temp_ptr = (struct node *)malloc(sizeof(struct node));
	printf("Enter the Element want to Push\n");
	scanf("%d", &item);
	temp_ptr->info = item;
	temp = start;

	if (start == NULL) {
		start = temp_ptr;
	} else {
		while (temp->next != NULL) {
			temp = temp->next;
		}
	temp->next = temp_ptr;
	temp_ptr->next = NULL;
	}

}


void display()
{
	struct node * temp;
	temp = start;
	if (temp == NULL)
		printf("Queue is Empty..\n");
	else {
		do {
			printf(":- %d\n", temp->info);
			temp = temp->next;
		} while((temp != NULL));
	}
}


void remov()
{
	int item;
	struct node * temp;
	
	if (start == NULL)
		printf("Queue is Empty....\n");
	else {
		temp = start;
		start = start->next;
		free(temp);
	}

}




