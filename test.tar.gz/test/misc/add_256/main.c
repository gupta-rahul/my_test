#include<stdio.h>
#include<stdlib.h>
#include<string.h>


void get_token(char * str, int num[256], int *index);
void rem_null(char *str);
void addition(int opd1[256], int opd2[256], int res[256]);

int op1[256];
int op2[256];
int result[256];
int op1_index = 0;
int op2_index = 0;
int res_index = 0;
int start_stor_index = 255;

int main(void)
{
    int i;

    char *string1 = NULL;
    char *string2 = NULL;

    string1 = (char *)malloc(sizeof(char) * 256);
    string2 = (char *)malloc(sizeof(char) * 256);

    printf("Enter the First Number:- ");
    fgets(string1, 256, stdin);
    printf("Enter the Second Number:- ");
    fgets(string2, 256, stdin);

    rem_null(string1);
    rem_null(string2);
    
    get_token(string1, op1, &op1_index);
    get_token(string2, op2, &op2_index);
/*
    for ( i = 0; i <= op1_index; i++) {
        printf("%d\t", op1[i]);
    }

    printf("\n");    

    for (i = 0; i <= op2_index; i++) {
        printf("%d\t", op2[i]);
    }

    printf("\n");
*/
    addition(op1, op2, result);

    for (i = (start_stor_index); i  <= 255; i++) {
        printf(" %d ", result[i]);
    }
    
    printf("\n");
    return 0;

}

void get_token(char * str, int num[256], int *index)
{
    char ch;
    int loop = *index;

        while( *str != '\0') {
            ch = *str;
            if (ch != '\0')
            num[loop++] = ch - 48;
            str++;
        }
        *index = --loop;
        printf("\n");
}

void rem_null(char *str)
{
        while( *str++ != '\0') {
            if (*str == '\n')
                *str = '\0';
        }
}

void addition(int opd1[256], int opd2[256], int res[256])
{
    int i;
    
    int temp = 0;

    int cal_index = 0 ;

    (op1_index > op2_index) ? (cal_index = op2_index) : (cal_index = op1_index);

    for ( i = 0; i <= cal_index; i++) {
        
        temp = op1[op1_index--] + op2[op2_index--] + temp;
        
        if (temp > 9) {
            res[start_stor_index--] = temp % 10;
            temp = temp / 10;
        } else {
            res[start_stor_index--] = temp;
            temp = 0;
        }
    }
     
    if (op1_index > op2_index) {
        while (op1_index != -1) {
            if ((op1[op1_index] + temp) > 9) {
                res[start_stor_index--] = (op1[op1_index] + temp) % 10;
                temp = (op1[op1_index] + temp) / 10;
                --op1_index;
            } else {
            res[start_stor_index--] = op1[op1_index--] + temp;
            temp = 0;
            }
        }
    } else {
        while (op2_index != -1) {
            if ((op2[op2_index] + temp) > 9) {
                res[start_stor_index--] = (op2[op2_index] + temp) % 10;
                temp = (op2[op2_index] + temp) / 10;
                --op2_index;
             } else {
                    res[start_stor_index--] = op2[op2_index--] + temp;
            temp = 0;
            }
        }
    }
    
    if (temp != 0)
      res[start_stor_index--] = temp;
    ++start_stor_index;        
}
