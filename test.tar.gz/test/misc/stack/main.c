#include<stdio.h>
#include<stdlib.h>


struct node {
	struct node * next;
	int info;
};

void display();
void push();
void pop();
	
struct node *start = NULL;

int main()
{
	int choice;


	while (1) {
	
	printf("Enter your Choice \n");
	printf("1. Push \n");
	printf("2. Pop \n");
	printf("3. Display\n");
	printf("4. Exit\n");
	scanf("%d", &choice);
	

	switch (choice) {
		case 1: push();
			break;	
		case 2: pop();
			break;	

		case 3: display();
			break;	

		case 4: exit(0);
			break;	
	}
	
	}
	return 0;
}



void push()
{
	int item;
	struct node *temp_ptr = NULL;
	temp_ptr = (struct node *)malloc(sizeof(struct node));
	printf("Enter the Element want to Push\n");
	scanf("%d", &item);
	temp_ptr->info = item;

	if (start == NULL) {
		start = temp_ptr;
	} else {
		temp_ptr->next = start;
		start = temp_ptr;
	}
}


void display()
{
	struct node * temp;
	temp = start;
	if (temp == NULL)
		printf("Stack is Empty..\n");
	else {
		do {
			printf(":- %d\n", temp->info);
			temp = temp->next;
		} while((temp != NULL));
	}
}


void pop()
{
	int item;
	struct node * temp;
	
	if (start == NULL)
		printf("Stack is Empty....\n");
	else {
		temp = start;
		start = start->next;
		free(temp);
	}

}




