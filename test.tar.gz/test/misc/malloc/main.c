#include<stdio.h>
#include<stdlib.h>
#include<string.h>


int main(void)
{
    int brk_val;
    void *sbrk_val;

    brk_val = brk(1000);
    
    printf("brk_val :-    %d\n", brk_val);

    sbrk_val = (void *)sbrk(0);

    printf("sbrk_val :- %p\n", sbrk_val);

    return 0;

}
