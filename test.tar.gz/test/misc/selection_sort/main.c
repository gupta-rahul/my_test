#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int i;
	int j;
	int k = 0;
	int pos;
	int temp;
	int arr[50];
	int size;
	
	printf("Enter the Enter the Number of Elements want to Entere \n");
	scanf("%d", &size);
	
	printf("Enter the Elements\n");
	for (i = 0; i < size; i++) {
		scanf("%d", &arr[i]);
	}
	
	printf("\nEntered Elements are:- ");
	for (i = 0; i < size; i++) {
		printf("%d\t", arr[i]);
	}
	printf("\n");
	
	for (i = 0; i < size; i++) {
		temp = arr[k];
		pos  = i;
		for (j = 0; j < (size - i); j++) {
			if (temp <= arr[j]) {
				temp = arr[j];
				pos = j;
			}
		}
		arr[pos] = arr[size - i - 1];
		arr[size - i - 1] = temp;
		k = 0;
	}
	
	printf("\nSorted Elements are:- ");
	for (i = 0; i < size; i++) {
		printf("%d\t", arr[i]);
	}
	
	printf("\n");

	return 0;
}
