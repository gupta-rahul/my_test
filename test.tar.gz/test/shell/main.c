#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    char *str = NULL;
    char *str2 = NULL;
    char *temp = NULL;
    char *temp2 = NULL;

    str = (char *)malloc(sizeof(char) * 50);
    str2 = (char *)malloc(sizeof(char) * 50);

    temp = str;
    temp2 = str2;

    if (fork()) {
        wait(NULL);
    } else {
        printf("$: ");
        fgets(str, 50, stdin);

        while (*temp != ' ')
            *temp2++ = *temp++;

        *temp2 = '\0';

        printf("str:- %s\tstr2:- %s\n", str, str2);

        execvp(str2, &str);
    }

    return 0;
}
