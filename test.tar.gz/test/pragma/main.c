#include<stdio.h>

//#pragma pack (2)
#pragma pack(push , 2)
#pragma pack(push , 4)
#pragma pack(push , 1)

struct abc1 {
    int aa;
    char ccc;
    int bb;
    char cc;
    int dd;
};

//#pragma pack (4)
#pragma pack(pop)

struct abc2 {
    int aa;
    char ccc;
    int bb;
    char cc;
    int dd;
};

//#pragma pack (1)
#pragma pack(pop)

struct abc3 {
    int aa;
    char ccc;
    int bb;
    char cc;
    int dd;
};

int main(void)
{
    struct abc1 aa1;
    struct abc2 aa2;
    struct abc3 aa3;

    printf("sizeof of Structure aa1:- %d\n", sizeof(aa1));
    printf("sizeof of Structure aa2:- %d\n", sizeof(aa2));
    printf("sizeof of Structure aa3:- %d\n", sizeof(aa3));

    return 0;
}
