#include<ker_ll.h>

int main(void)
{
	struct node *node1 = NULL;
	struct node *node2 = NULL;

	node1 = (struct node *)malloc(sizeof(struct node));
	node2 = (struct node *)malloc(sizeof(struct node));
	
	node1->a = 100;
	node2->a = 200;
	node1->b = 500;
	node2->b = 1000;

	node1->list.next = &node2->list;
	node1->list.prev = NULL;
	node2->list.prev = &node1->list;
	node2->list.next = NULL;

	printf("value of a in node 1 : - %d\n", node1->a );
	printf("value of a in node 2 : - %d\n", node2->a );

	printf("value of a in node 2 using node 1:- %d\n", *((int *)((char *)node1->list.next - offsetof(struct node,b))));

	return 0;
}
