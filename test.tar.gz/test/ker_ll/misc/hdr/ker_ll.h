#ifndef _KER_LL_H_
#define _KER_LL_H_

#include<stdio.h>
#include<stdlib.h>

#include<stddef.h>

struct list_head 
{
	struct list_head *next;
	struct list_head *prev;
};

struct node
{
	int a;
	int b;
	struct list_head list;
};


#endif
