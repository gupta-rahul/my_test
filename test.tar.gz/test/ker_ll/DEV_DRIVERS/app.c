#include<stdio.h>
#include<fcntl.h>

int main(void)
{

	int fd;
	char uBuffer[100];// = "character_device_driver";

	fd = open("/dev/char_dd", O_RDWR);
	if(fd < 0) 
		perror("Unable to open the device");
	else
		printf("File open successful : - %d\n", fd);

	printf("Enter the data to Write ......\n");
	fgets(uBuffer,sizeof(uBuffer),stdin);
      	write(fd,&uBuffer, sizeof(uBuffer));
		
	printf("Before Reading:- %s\n", uBuffer);
	
	read(fd, &uBuffer,sizeof(uBuffer));
	
	printf("After Reading:- %s\n", uBuffer);

      //	write(fd,&uBuffer, sizeof(uBuffer));
	
	close(fd);
	
	return 0;
}
