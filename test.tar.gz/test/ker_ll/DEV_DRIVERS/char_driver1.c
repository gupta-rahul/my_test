#include<linux/init.h>		
#include<linux/module.h>	
#include<linux/sched.h>
#include<linux/cdev.h>
#include<linux/uaccess.h>
#include<linux/device.h>
#include<linux/fs.h>

MODULE_LICENSE("Dual BSD/GPL");

#define FIRST_MINOR	15
#define NO_DEV	5

int my_open (struct inode *inode, struct file *filep);
int my_close(struct inode *inode, struct file *filep);
ssize_t my_read (struct file *filep, char __user *buffer, size_t length, loff_t *offset);
ssize_t my_write(struct file *filep, const char __user *buffer, size_t length, loff_t *offset);

static int my_init(void);
static void my_exit(void);

struct file_operations fops = {
	.owner = THIS_MODULE,
	.open = my_open,
	.release = my_close,
	.read = my_read,
	.write = my_write
};

char *device_name;	/* Contain Device Name */
int major_no;	
static dev_t my_dev;	/* hold major & minor number */	
struct cdev *my_cdev;	/*character device driver descriptor */

/* to accept input from the command Line */
module_param(device_name,charp,0000);

/* Class & Device Structue */
static struct class *mychar_class;
static struct device *mychar_device;

/* open Funtion */
int my_open (struct inode *inode, struct file *filep)
{
	printk(KERN_INFO "OPEN SUCCESSFULL\n");
	return 0;
}

/* Close Funtion */
int my_close(struct inode *inode, struct file *filep)
{
	printk(KERN_INFO "CLOSE SUCCESSFULL\n");
	return 0;
}

/* Read Function */
ssize_t my_read (struct file *filep, char __user *buffer, size_t length, loff_t *offset)
{
	int retVal;
	char kbuffer[] = "KERNEL_DATA_COPIED";
	retVal = copy_to_user(buffer,&kbuffer,sizeof(kbuffer));
	if (retVal != 0)
		printk(KERN_INFO "Reading Failed\n");
	return length ;
}

/* Write Function */
ssize_t my_write(struct file *filep, const char __user *buffer, size_t length, loff_t *offset)
{
	int retVal;
	char kbuffer[100] = "KERNEL_DATA_COPIED";
	printk(KERN_INFO "Before Writing:- %s\n", kbuffer);
	retVal = copy_from_user(&kbuffer,buffer,length);
	if (retVal != 0)
		printk(KERN_INFO "Writing Failed\n");
	printk(KERN_INFO "After Writing:- %s\n", kbuffer);

	return length;
}

static int __init my_init(void)
{
	int status;

	printk(KERN_INFO "Starting Character Device \n");

	/*Allocating Device Number */

	status = alloc_chrdev_region(&my_dev,FIRST_MINOR, NO_DEV, device_name);
	if (status < 0 ) {
		printk(KERN_INFO "Device Number allocation failed: %d\n", status);
	}

	printk(KERN_INFO "Major Number :-%d\t Minor Number :- %d\n", MAJOR(my_dev), MINOR(my_dev));

	/* Allocation Memory for my_CDEV*/
	my_cdev = cdev_alloc();
	if (my_cdev == NULL) {
		printk(KERN_INFO "Cdev Allocation Failed\n");
	}


	/* Initialization of CDEV with file_operation fops*/
	cdev_init(my_cdev, &fops);
	my_cdev->owner = THIS_MODULE;

	/* Adding my_cdev to the List */
	status = cdev_add(my_cdev,my_dev, NO_DEV);
	if (status) {
		printk(KERN_INFO "Cdev Add Failed\n");
	}

	/* Create a class & an entry in sysfs */
	mychar_class = class_create(THIS_MODULE, device_name);
	if (IS_ERR(mychar_class)) {
		printk(KERN_INFO " Class creation failed \n");
	}

	/* Create mychar_device in sysfs and an device entry will be made in dev directory */

	mychar_device = device_create(mychar_class, NULL, my_dev, NULL, device_name);

	if (IS_ERR(mychar_device)) {
		printk(KERN_INFO "device created filed \n");
	}

	return 0;
}

static void my_exit(void)
{
	printk(KERN_INFO "EXITING THE CHAR DRIVER\n");
	device_destroy(mychar_class, my_dev);
	class_destroy(mychar_class);
	cdev_del(my_cdev);
	unregister_chrdev_region(my_dev, NO_DEV);
}

module_init(my_init);
module_exit(my_exit);
