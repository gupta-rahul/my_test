#include <stdio.h>

#define OFFSETOF(TYPE, MEMBER)	({typeof(TYPE) *ptr = NULL; (unsigned)&ptr->MEMBER;})


typedef struct abc 
{
	double tt;
	int aa;
	char bb;
	double cc;
}var;

int main()
{
   printf("offset of bb :- %u\n", OFFSETOF(var, bb));
   printf("offset of tt :- %u\n", OFFSETOF(var, tt));
   printf("offset of cc :- %u\n", OFFSETOF(var, cc));
   return 0;
}
