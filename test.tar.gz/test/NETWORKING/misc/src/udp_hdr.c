#include<raw_socket.h>


void udp_hdr_display(struct udphdr *udp_hdr)
{
    printf("*******************UDP_HEADER***************************\n");
    printf("size of UDP_HDR:- %d\n", sizeof(struct udphdr));
    printf("source:- %d\n", udp_hdr->source);
    printf("dest:- %d\n",  udp_hdr->dest);
    printf("length:- %d\n", udp_hdr->len);
    printf("Check:- %d\n",  udp_hdr->check);
    printf("\n\n");
}

