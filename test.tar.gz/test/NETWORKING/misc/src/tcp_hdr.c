#include<raw_socket.h>

void tcp_hdr_display(struct tcphdr *tcp_hdr)
{
    printf("*******************TCP_HEADER*****************************\n");
    printf("size of TCP_HDR:- %d\n", sizeof(struct tcphdr));
    printf("source:- %d\n", tcp_hdr->source);
    printf("dest:- %d\n", tcp_hdr->dest);
    printf("seq:- %d\n", tcp_hdr->seq);
    printf("ack_seq:- %d\n", tcp_hdr->ack_seq);
    printf("doff:- %d\n", tcp_hdr->doff);
    //printf("res1:-%d\n", tcp_hdr->resl);
    printf("cwr:- %d\n", tcp_hdr->cwr);
    printf("ece:- %d\n", tcp_hdr->ece);
    printf("urg:- %d\n", tcp_hdr->urg);
    printf("ack:- %d\n", tcp_hdr->ack);
    printf("psh:- %d\n", tcp_hdr->psh);
    printf("rst:- %d\n", tcp_hdr->rst);
    printf("syn:- %d\n", tcp_hdr->syn);
    printf("fin:- %d\n", tcp_hdr->fin);
    printf("window:- %d\n", tcp_hdr->window);
    printf("check:- %d\n", tcp_hdr->check);
    printf("urg_ptr:- %d\n", tcp_hdr->urg_ptr);
    printf("\n\n");
}



