#include<raw_socket.h>

int main(int agc, char *argv[])
{
    char *opt = NULL;

    opt = "eth0";

    char *data = NULL;

    char *buffer = NULL;

    char outpack[MAXPACKET];

    int len;    /* No. of bytes recvd*/

    int cc;

    int packlen;
   

    unsigned char *packet;

    int datalen;

    int res_send;

    struct icmp *icp;

    buffer = (char *)malloc(SIZE);

    struct sockaddr_in to, from;

    int sock_fd;
    struct proto *prot;
    struct iphdr *ip_hdr;
    struct ethhdr *eth_hdr;
    struct udphdr *udp_hdr;
    struct tcphdr *tcp_hdr;


    to.sin_family = AF_INET;
    to.sin_addr.s_addr = inet_addr(argv[1]);

    /*Creating Raw Socket*/
    //sock_fd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP));
    sock_fd = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP); 

    perror("socket");

    /* Binding interface to the Socket */
    setsockopt(sock_fd, SOL_SOCKET , SO_BINDTODEVICE, opt, sizeof(opt));

    perror("setsockopt");

	icp = (struct icmp *)outpack;
	icp->icmp_type = ICMP_ECHO;
	icp->icmp_code = 0;
	icp->icmp_cksum = 0;
	icp->icmp_seq = 12345;	/* seq and id must be reflected */
	icp->icmp_id = getpid();

    packet = (u_char *)malloc((u_int)packlen);        
        
    while (1) {

    //  res_send = sendto(s, (char *)outpack, cc, 0, (struct sockaddr*)&to, (socklen_t)sizeof(struct sockaddr_in));

    /* Reading from  the interface */
   
        len = recvfrom(sock_fd, buffer, SIZE, 0, NULL, NULL);

        if (len < 0)
            perror("recvfrom");

        printf("%d bytes read\n", len);

        ip_hdr = (struct iphdr *)(buffer + sizeof(struct ethhdr));
        eth_hdr = (struct ethhdr *)buffer;

    /* Display ETH_HDR*/
        eth_hdr_display(eth_hdr);

    /* Display IP_HDR */
        ip_hdr_display(ip_hdr);
    
        if (ip_hdr->protocol == 6) {
            //printf("%s\n",(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr)) + sizeof(struct tcphdr));
            tcp_hdr = (struct tcphdr *)(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr));
    /* Display TCP_HDR*/
            tcp_hdr_display(tcp_hdr);
        } else if (ip_hdr->protocol == 17){
            //printf("%s\n",(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr)) + sizeof(struct udphdr));
            udp_hdr = (struct udphdr *)(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr));
    /*Display UDP_HDR*/
            udp_hdr_display(udp_hdr);
        }
    }

    close(sock_fd);

    return 0;
}
