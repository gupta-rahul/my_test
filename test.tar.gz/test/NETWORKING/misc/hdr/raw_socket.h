#ifndef _RAW_SOCKET_
#define _RAW_SOCKET_
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
//#include <linux/ip.h>
#include<linux/if_ether.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<net/if.h>
#include<linux/udp.h>
#include<linux/tcp.h>
//#include <netinet/ip.h>
//#include<linux/icmp.h>
#include <netinet/ip_icmp.h>
#define SIZE 1024
#define SERVERPORT 5000
#define MAXPACKET 65536

char *check_protocol(int protocol);
void ip_hdr_display(struct iphdr *ip_hdr);
void eth_hdr_display(struct ethhdr *eth_hdr);
void tcp_hdr_display(struct tcphdr *tcp_hdr);
void udp_hdr_display(struct udphdr *udp_hdr);

#endif
