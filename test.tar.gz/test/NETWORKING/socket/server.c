#include<sys/types.h>  
#include<sys/socket.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<netinet/in.h>
#include <arpa/inet.h>
#define Q_LIMIT 1

int main(int argc, char *argv[])
{
    int sockid;

    int client_sockid;
    
    int status;

    int port_num;

    int send_status;

    int receive_status;
   
    socklen_t addr_len;

    char *send_buff = "This is Server...";

    char *recv_buff = NULL;
    
    struct in_addr address;
    
    struct sockaddr_in sock_addr;
    
    struct sockaddr_in recv_sock_addr;

    recv_buff = (char *)malloc(sizeof(char) * 256);

    memset(&sock_addr, '0', sizeof(sock_addr));

    /* Conveting internet host address to binary form */
    inet_aton(argv[1], &address);

    port_num = atoi(argv[2]);
    
    /* Structure describing an Internet (IP) socket address. */
    sock_addr.sin_family = AF_INET;
    sock_addr.sin_port = htons(port_num);
    //sock_addr.sin_addr = address;
    sock_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    printf("inet_aton:- %u\n", sock_addr.sin_addr.s_addr);
    
    printf("inet_ntoa:- %s\n", inet_ntoa(sock_addr.sin_addr));

    /* create an endpoint for communication */
    sockid = socket(AF_INET, SOCK_STREAM , 0);
    perror("sockid");

    if (sockid < 0)
            printf("Socket Creation Failed in Server\n");

    /* Binding to Socket */
    status = bind(sockid, (struct sockaddr *)&sock_addr, sizeof(struct sockaddr));
    perror("bind"); 

    if (status < 0)
        printf("Binding failed in server..\n");
    
    /* Listening */
    status = listen(sockid, Q_LIMIT);
    perror("listen");

    if (status < 0)
        printf("Listeing Failed in server..\n");

    addr_len = sizeof(struct sockaddr_in);

    /* Accepting */ 
    client_sockid = accept(sockid, (struct sockaddr *)&recv_sock_addr, &addr_len);
    perror("accept");
   
    if (status < 0)
        printf("Accepting failed in server..\n");
    
    /* Receving */
    while (1) {

        receive_status = recv(client_sockid, (void *)recv_buff, 256, 0);
        if (receive_status < 0)
            printf("Receving failed in server..\n");
        else 
            printf("Received in Server: -     %s\n", (char *)recv_buff);

        bzero(recv_buff, 256);
    
    /* Sending */
/*    send_status = send(sockid, (void *)send_buff, strlen(send_buff), MSG_CONFIRM | MSG_DONTWAIT  | MSG_MORE );
    if (send_status < 0)
        printf("Sending failed in server..\n");
*/
    }
    /* close */
    status = close(sockid);
    
    if (status < 0)
        printf("Closing of Socket failed in server..\n");

    return 0;
}
