#include<raw_socket.h>


void ip_hdr_display(struct iphdr *ip_hdr)
{
    int i;
    int *ptr;
    ptr = (int *)ip_hdr;

    printf("*******************IP_HEADER****************************\n");
//    printf("sizeof(struct eth_hdr):- %d\n", sizeof(struct ethhdr)); 
//    for (i = 0; i < sizeof(struct iphdr); i++) {
//            printf("%x ", *ptr++);
//    }
    printf("size of IP_HDR:- %d\n", sizeof(struct iphdr));
    printf("ihl:- %d\n", ip_hdr->ihl);
    printf("version:- %d\n", ip_hdr->version);
    printf("tos:- %d\n", ip_hdr->tos);
    printf("tot_len:- %d\n", ip_hdr->tot_len);
    printf("id:- %d\n", ip_hdr->id);
    printf("frag_off:- %d\n", ip_hdr->frag_off);
    printf("ttl:- %d\n", ip_hdr->ttl);
    printf("protocol:- %s\n", check_protocol(ip_hdr->protocol));
    printf("check:- %d\n", ip_hdr->check);
    printf("saddr:- %s\n", inet_ntoa(ip_hdr->saddr));
    printf("daddr:- %s\n", inet_ntoa(ip_hdr->daddr));
}

