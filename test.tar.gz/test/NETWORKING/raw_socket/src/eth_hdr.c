#include<raw_socket.h>


void eth_hdr_display(struct ethhdr *eth_hdr)
{
    int i;
    int j;
    char *ptr = NULL;
    ptr = (char *)eth_hdr;

    printf("*******************ETH_HEADER***************************\n");
//    printf("sizeof(struct eth_hdr):- %d\n", sizeof(struct ethhdr)); 
//  for (i = 0; i < sizeof(struct ethhdr) ; i++) {
//        printf("%x ", *ptr++);
//    }

    printf("\n");

    printf("Dest_eth_addr:- %.2x-%.2x-%.2x-%.2x-%.2x-%.2x \n", eth_hdr->h_dest[0], eth_hdr->h_dest[1],
        eth_hdr->h_dest[2], eth_hdr->h_dest[3], eth_hdr->h_dest[4], eth_hdr->h_dest[5]);   /* destination eth addr */
    printf("Srce_eth_addr:- %.2x-%.2x-%.2x-%.2x-%.2x-%.2x \n", eth_hdr->h_source[0], eth_hdr->h_source[1],
        eth_hdr->h_source[2], eth_hdr->h_source[3], eth_hdr->h_source[4], eth_hdr->h_source[5]); /* sorce eth addr */
    printf("Packet_Id_field:- %d\n", eth_hdr->h_proto);        /* packet type ID field */
}
