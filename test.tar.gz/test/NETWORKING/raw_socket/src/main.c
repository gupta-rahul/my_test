#include<raw_socket.h>

void icmp_hdr_display(struct icmphdr *icmp_hdr);
        
int main(int agc, char *argv[])
{
    char *opt = NULL;

    opt = "eth0";

    char *data = NULL;

    char *buffer = NULL;

    int len;    /* No. of bytes recvd*/

    buffer = (char *)malloc(SIZE);

    int sock_fd;

    struct iphdr *ip_hdr;
    struct ethhdr *eth_hdr;
    struct udphdr *udp_hdr;
    struct tcphdr *tcp_hdr;
    struct icmphdr *icmp_hdr;

    /*Creating Raw Socket*/
    sock_fd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP));
    //sock_fd = socket(AF_INET, SOCK_RAW, htons(IPPROTO_ICMP));

    perror("socket");

    /* Binding interface to the Socket */
    setsockopt(sock_fd, SOL_SOCKET , SO_BINDTODEVICE, opt, sizeof(opt));

    perror("setsockopt");

    while (1) {
    /* Reading from  the interface */
        len = recvfrom(sock_fd, buffer, SIZE, 0, NULL, NULL);

        if (len < 0)
            perror("recvfrom");

        printf("%d bytes read\n", len);

        ip_hdr = (struct iphdr *)(buffer + sizeof(struct ethhdr));
        icmp_hdr = (struct icmphdr *)(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr));
        eth_hdr = (struct ethhdr *)buffer;

        icmp_hdr_display(icmp_hdr);
    /* Display ETH_HDR*/
        eth_hdr_display(eth_hdr);

    /* Display IP_HDR */
        ip_hdr_display(ip_hdr);

        if(ip_hdr->protocol == 1)
                printf("ICMP Protocol\n");
    
        if (ip_hdr->protocol == 6) {
    //        printf("data:- %s\n",(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr)) + sizeof(struct tcphdr) + sizeof(struct icmphdr) + 56);
    //        printf("data:- %s\n",(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr)) + sizeof(struct tcphdr) + sizeof(struct icmphdr) + 36);
            tcp_hdr = (struct tcphdr *)(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr));
    /* Display TCP_HDR*/
            tcp_hdr_display(tcp_hdr);
        } else if (ip_hdr->protocol == 17){
    //       printf("data:- %s\n",(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr)) + sizeof(struct udphdr) + sizeof(struct icmphdr) + 56);
    //       printf("data:- %s\n",(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr)) + sizeof(struct tcphdr) + sizeof(struct icmphdr) + 36);
            udp_hdr = (struct udphdr *)(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr));
    /*Display UDP_HDR*/
            udp_hdr_display(udp_hdr);
        }
    }

    close(sock_fd);

    return 0;
}


void icmp_hdr_display(struct icmphdr *icmp_hdr)
{
    printf("****************************ICMP_HDR************************\n");
    printf("size of ICMP_HDR:- %d\n", sizeof(struct icmphdr));
    printf("type:- %d\n",icmp_hdr->type);
    printf("code:- %d\n",icmp_hdr->code);
    printf("checksum:- %d\n",icmp_hdr->checksum);
}
