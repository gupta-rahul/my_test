#include<raw_socket.h>

char *check_protocol(int protocol)
{
    switch(protocol) {

        case 6: return "TCP Protocol";
            break;

        case 17: return "UDP Protocol";
            break;
    }
}
