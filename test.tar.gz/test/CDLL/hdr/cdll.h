#ifndef _CDLL_H_
#define _CDLL_H_

#include<stdio.h>
#include<stdlib.h>

struct list {							/* Sub list Structure */
        struct list *prev_ptr;
        struct list *next_ptr;
        int info;
};

struct cdll {							/* Main list structure */
	struct cdll *prev_ptr;
	struct cdll *next_ptr;
	struct list *list_ptr;
};

int create_option(struct cdll **cdll_start);			/* Function for Create Option */

int display_option(struct cdll **cdll_start);			/* Function for Display Option */

int search_option(struct cdll **cdll_start);			/* Function for Search Option */

int insert_option(struct cdll **cdll_start);			/* Function for Insert Ooption */

int delete_option(struct cdll **cdll_start);			/* Function for Delete Option */

int delete_entire_list(struct cdll **cdll_start);		/* Function for Deleting Entire List */

int delete_entire_system(struct cdll **cdll_start);		/* Function for Deleting Entire System */

int delete_value_pos(struct cdll **cdll_start);			/* Function for Deleting value at position */
		
int delete_node(struct cdll **cdll_start);			/* Function for Deleting Node */

int del_after_before(struct cdll **cdll_start, int opt);	/* Function for Deleting after & Before Value */
	
void create_cdll_beg(struct cdll **cdll_start);			/* Function for creating before node*/

void create_cdll_end(struct cdll **cdll_start);			/* Function for creating after node*/

void display_forward(struct cdll **cdll_start);			/* Function for  Displaying in forward direction */

void display_all_list(struct cdll **cdll_start);		/* Function for Displaying all List */

void display_reverse(struct cdll **cdll_start);			/* Function for Displaying in Reverse Direction */

void insert_list_beg(struct cdll **cdll_start);			/* Function for inserting node in list at begining */

void insert_list_end(struct cdll **cdll_start);			/* Function for inserting node in list at end */

int search_in_list(struct cdll **cdll_start);			/* Function for Searching in List */

int search_in_system(struct cdll **cdll_start);			/* Function for Searching in System */

int insert_list_pos(struct cdll **cdll_start, int pos);		/* Function for inserting in List at position */

int total_list(struct cdll **cdll_start);			/* Function for Displaying total number of LIst */

int node_count(struct list *list_start);			/* Function for Counting number of Node in List */

int max_min_in_list(struct cdll **cdll_start, int opt);		/* Function for getting max & min in List */

int max_min_in_system(struct cdll **cdll_start, int opt);	/* Function for getting max & Min in System */

int del_first_last_node(struct cdll **cdll_start, int opt);	/* Function for deleting first & last node in System */

#endif 
