/*
	Function for Display Option 
*/


#include<cdll.h>

int display_option(struct cdll **cdll_start)
{
	int choice;			/* int Variable */

	while (1) {
	printf("\nDisplay operations\n");
	printf("1. Forward display\n");
	printf("2. Reverse display\n");
	printf("3. Display all the list in the system\n");
        printf("4. Return to Main Menu\n");
	printf("5. Exit\n");
	printf("Enter Choice\n");

        scanf("%d", &choice);

        switch(choice) {
	
	case 1:	display_forward(cdll_start);	
		break;

	case 2:	display_reverse(cdll_start);	
		break;
	
	case 3:	display_all_list(cdll_start);
		break;
	
	case 4:	return (0);
	
	case 5:	exit(1);
	}

	}
}
