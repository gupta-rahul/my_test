/*
	Function for Delete Option 
*/


#include<cdll.h>

int delete_option(struct cdll **cdll_start)
{

	int choice = 0;			 /* int variable for Choice */
	int del_first = 1;		 /* int variable for delete first option */
	int del_last = 2;		 /* int variable for delete last option */
	int del_after = 1;		 /* int variable for delete after option */
	int del_before = 2;		 /* int variable for delete before option */

        while (1) {

	printf("Delete operations\n");
	printf("1. Delete a value in a particular list\n");
	printf("2. Delete a node after a particular value in the list\n");
	printf("3. Delete a node before a particular value in the list\n");
	printf("4. Delete first node of a particular list\n");
	printf("5. Delete last node of a particular list\n");
	printf("6. Delete node at a given position in a given list\n");
	printf("7. Delete the entire list\n");
	printf("8. Return to main menu\n");
	printf("Enter Choice\n");
	scanf("%d", &choice);
	
	switch(choice) {
	
	case 1:	delete_value_pos(cdll_start);
		break;

	case 2:	del_after_before(cdll_start, del_after);
		break;
	
	case 3:	del_after_before(cdll_start, del_before);
		break;

	case 4:	del_first_last_node(cdll_start, del_first);	
		break;

	case 5:	del_first_last_node(cdll_start, del_last);
		break;
	
	case 6:	delete_node(cdll_start);	
		break;

	case 7:	delete_entire_list(cdll_start);	
		break;

	case 8:return (0);

	}

	}
}
