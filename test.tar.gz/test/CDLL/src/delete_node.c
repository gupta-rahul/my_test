#include<cdll.h>

int delete_node(struct cdll **cdll_start)
{
	int node;                               /* Int variable for node to delete  */
        int list_num;                           /* int variable for list number */
        int list_size;                          /* int variable for size of list */
        int count = 0;                          /* counter variable */
        int count1 = 0;                         /* counter variable */
        int flag = 0;                           /* flag variable */
        int flag1 = 0;                          /* flag variable */

        struct cdll *cdll_start_ptr = NULL;     /* cdll Start address */
        struct list *list_start_ptr = NULL;     /* list start Address */

        struct cdll *temp_cdll = NULL;          /* For traversing cdll */
	struct list *temp_list = NULL;          /* For Traversing List */
	struct list *temp_list1 = NULL;         /* For Traversing List */

	cdll_start_ptr = *cdll_start;
	list_start_ptr = cdll_start_ptr->list_ptr;

	temp_cdll = *cdll_start;

	printf("Enter the List Number\n");
	scanf("%d", &list_num);

	printf("Enter the Node to Delete\n");
	scanf("%d", &node);

	while(1) {
		++count;
		if (count == list_num) {
			flag = 1;
			break;
		}
		if (temp_cdll->next_ptr == *cdll_start)
			break;
		temp_cdll = temp_cdll->next_ptr;
	}

	printf("Searching in List %d\n", count);

	temp_list = temp_cdll->list_ptr;
	temp_list1 = temp_cdll->list_ptr;

	if (flag == 0) {
		printf("List is not present....Enter Valid List \n");
		temp_cdll = *cdll_start;
		count = 0;
		return 0;
	}

	/* Checking whether the LIst is Empty or Not */
	if (temp_list == NULL) {
		printf("List is Empty.....");
		exit(1);
	}

	/* searching for node to delete */
	while(1) {
		++count1;
		if (node == count1) {
			flag1 = 1;
			break;
		}
		if (temp_list1->next_ptr == temp_list)
			break;
		temp_list1 = temp_list1->next_ptr;
	}

	if (flag1 == 0)
		printf("Item Not Found in List\n");
	else
	{
		if (temp_list1 == temp_list->next_ptr){
			temp_cdll->list_ptr = NULL;	
		} else {		
			temp_list1->prev_ptr->next_ptr = temp_list1->next_ptr;
			temp_list1->next_ptr->prev_ptr = temp_list1->prev_ptr;
			if (temp_list1 == temp_cdll->list_ptr)
				temp_cdll->list_ptr = temp_list1->next_ptr;
		}
		free(temp_list1);
		temp_list = NULL;
	}

}

