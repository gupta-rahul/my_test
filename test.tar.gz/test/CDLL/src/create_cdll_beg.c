/*
	create a CDLL by inserting elements at the beginning
*/

#include<cdll.h>

void create_cdll_beg(struct cdll **cdll_start)
{

	struct cdll *temp_cdll_ptr = NULL;			/* Pointer of Stuct cdll Type */
	struct cdll *temp_ptr1 = NULL;				/* Pointer of Stuct cdll Type */
	struct cdll *temp_ptr2 = NULL;				/* Pointer of Stuct cdll Type */
	
	temp_ptr1 = *cdll_start;
	
	/* Memory Allocation */
	if ((temp_cdll_ptr = (struct cdll *)malloc(sizeof(struct cdll))) == NULL)
		printf("Memory Allocation failed in create_cdll_beg for temp_cdll_ptr");
	
	if (temp_ptr1 == NULL) {
		temp_cdll_ptr->next_ptr = temp_cdll_ptr;
		temp_cdll_ptr->prev_ptr = temp_cdll_ptr;
		*cdll_start = temp_cdll_ptr;
	} else {
		temp_ptr2 = temp_ptr1->prev_ptr;
		temp_ptr2->next_ptr = temp_cdll_ptr;
		temp_cdll_ptr->next_ptr = temp_ptr1;
		temp_cdll_ptr->prev_ptr = temp_ptr2;
		*cdll_start = temp_cdll_ptr;
	}
}
