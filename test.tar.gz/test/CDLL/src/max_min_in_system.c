/*
	Function for searching max & min in system
*/


#include<cdll.h>

int max_min_in_system(struct cdll **cdll_start, int opt)
{

	int max_num;				/* int variable for max number in system */
	int min_num;				/* int variable for min number in system*/
	int max_pos;				/* int variable for max number position in system*/
	int max_list;				/* int variable for list number of max number in system */
	int min_pos;				/* int variable for min number in system */
	int min_list;				/* int variable for list number min number in system*/
	int max_min_opt;			/* int variable for max min option */
        int count = 0;                          /* counter variable */
        int count1 = 0;                         /* counter variable */
        int flag = 0;                           /* flag variable */

	struct cdll *temp_cdll_ptr = NULL;
	struct cdll *temp_cdll = NULL;

	struct list *temp_list = NULL;
	struct list *temp_list1 = NULL;
	
	temp_cdll_ptr = *cdll_start;
	temp_cdll = *cdll_start;
	
	max_min_opt = opt;
	if (temp_cdll_ptr == NULL)
	printf("Nothing to Display\n");

        while(1) {
                temp_list1 = temp_cdll->list_ptr; 
                temp_list = temp_cdll->list_ptr; 
		++count;
		if (temp_list != NULL) {
 			if (flag == 0) {
			max_num = temp_list1->info;
                	min_num = temp_list1->info;
			max_list = count;
			max_pos = 1;
			min_list = count;
			min_pos = 1;
			flag = 1;
			}
			while(1) {					/* max & min Searching */
				++count1;
				if ( max_num < temp_list1->info) {
					max_list = count;
		                        max_pos = count1;
        		               	max_num = temp_list1->info;
				}
                		if ( min_num > temp_list1->info) {
                        	        min_list = count;
                        		min_pos = count1;
					min_num = temp_list1->info;
				}
				if (temp_list1->next_ptr == temp_list)
	        	                break;
        			temp_list1 = temp_list1->next_ptr;
			}
			count1 = 0;
		}		
                if (temp_cdll->next_ptr == *cdll_start)
                        break;
                temp_cdll = temp_cdll->next_ptr;
        }

        if (max_min_opt == 1)
                printf("Max item in system %d List number = %d & Pos = %d\n", max_num, max_list, max_pos);
        else
                printf("Min item in system %d List number = %d & Pos = %d\n", min_num, min_list, min_pos);

}
