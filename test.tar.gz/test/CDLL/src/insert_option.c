/*
	Function for Insert option 
*/

#include<cdll.h>

int insert_option(struct cdll **cdll_start)
{
        int choice = 0;				/* int variable for choice */
	int at_pos = 1;				/* int variable for at_pos option */
	int before_pos = 2;			/* int variable for before pos option */
	int after_pos = 3;			/* int variable for after position option */
	
        while (1) {

	printf("Insert operations\n");
	printf("1. Insert a value to a particular list at the beginning of the list\n");
	printf("2. Insert a value to a particular list at the end of the list\n");
	printf("3. Insert a value to a particular list after a given value in that list\n");
	printf("4. Insert a value to a particular list before a given value in that list\n");
	printf("5. Insert a value to a particular list at a given position\n");
	printf("6. Return to Main Menu\n");
	printf("Enter the Choice\n");

        scanf("%d", &choice);

        switch(choice) {
	
	case 1:	insert_list_beg(cdll_start);
		break;

	case 2:	insert_list_end(cdll_start);
		break;

	case 3:	insert_list_pos(cdll_start, after_pos);
		break;

	case 4:	insert_list_pos(cdll_start, before_pos);
		break;

	case 5:	insert_list_pos(cdll_start, at_pos);
		break;

	case 6:	return (0);

	}

	}

}
