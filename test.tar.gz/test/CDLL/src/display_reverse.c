/*
	Function for Displaying nodes in List in Reverse Direction 
*/

#include<cdll.h>

void display_reverse(struct cdll **cdll_start)
{

	int list_num;
	int count = 0;
	int flag = 0;
	
	struct cdll *temp_cdll_ptr = NULL;
	struct cdll *temp_cdll = NULL;

	struct list *temp_list_ptr = NULL;
	struct list *temp_list = NULL;
	
	temp_cdll_ptr = *cdll_start;
	temp_cdll = *cdll_start;

enter:	printf("Enter the list Number\n");
	scanf("%d", &list_num);
	
	if (temp_cdll_ptr == NULL)
	printf("Nothing to Display\n");
	
	/* getting list from List */        
	while(1) {
                ++count;
                if (count == list_num) {
                        flag = 1;
                        break;
                }
                if (temp_cdll->next_ptr == *cdll_start)
                        break;
                temp_cdll = temp_cdll->next_ptr;
        }
	if (flag == 0) {
		printf("List is Not there...\n");
		exit(1);
	}

	
	temp_list_ptr = temp_cdll->list_ptr;
	temp_list = temp_cdll->list_ptr;
	
	if (temp_list_ptr == NULL) {
		printf("No list is There....Please Enter another List Number\n");
		count = 0;
		temp_cdll = *cdll_start;
		goto enter;
	}	
	
	temp_list_ptr = temp_list_ptr->prev_ptr;
	temp_list = temp_list->prev_ptr;

	/*Displaying nodes of list */
	while (temp_list_ptr->prev_ptr != temp_list) {
		printf("info- %d\n ", temp_list_ptr->info);
		temp_list_ptr = temp_list_ptr->prev_ptr;	
	}
		printf("info- %d\n ", temp_list_ptr->info);

}
