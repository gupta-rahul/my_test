/*
	Function for Searching item in System 
*/

#include<cdll.h>

int search_in_system(struct cdll **cdll_start)
{

	int count = 0;			/* counter variable */
	int count1 = 0;			/* counter variable */
	int item;			/* int variable for item */

	struct cdll *temp_cdll_ptr = NULL;
	struct cdll *temp_cdll = NULL;

	struct list *temp_list_ptr = NULL;
	struct list *temp_list = NULL;
	
	temp_cdll_ptr = *cdll_start;
	temp_cdll = *cdll_start;
	
	if (temp_cdll_ptr == NULL)
	printf("Nothing to Display\n");

	printf("Enter the Item to search \n");
	scanf("%d", &item);

	/* Searching item */	
        while(1) {
                temp_list_ptr = temp_cdll->list_ptr;
                temp_list = temp_cdll->list_ptr; 
        	++count;
		if (temp_list_ptr != NULL) {
			while(1) {
				++count1;
				if (item == temp_list_ptr->info)
					printf("Item %d is found in List %d & Position = %d\n", item, count, count1);
				if (temp_list_ptr->next_ptr == temp_list)
	        	                break;
        			temp_list_ptr = temp_list_ptr->next_ptr;
			}
			count1 = 0;
		}		
                if (temp_cdll->next_ptr == *cdll_start)
                        break;
                temp_cdll = temp_cdll->next_ptr;
        }
		
}
