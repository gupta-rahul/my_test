/*
	Function for Create Option
*/

#include<cdll.h>

int create_option(struct cdll **cdll_start)
{
	
	int choice = 0;					/* int variable */
	
	while (1) {
	
	printf("Creation of Lists\n");
	printf("1. create a CDLL by inserting elements at the beginning\n");
	printf("2. create a CDLL by inserting elements at the end\n");
	printf("3. Return to Main Menu\n");
	printf("4. Exit\n");
	printf("Enter Choice\n");
	
	scanf("%d", &choice);

	switch(choice) {
	
	case 1:	create_cdll_beg(&*cdll_start);	
		break;

	case 2:	create_cdll_end(&*cdll_start);
		break;
	
	case 3:	return 0;
	
	case 4:	exit(1);

	}

	}

}
