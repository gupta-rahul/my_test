/*
	Function for displaying total list in system 
*/

#include<cdll.h>

int total_list(struct cdll **cdll_start)
{

	int count = 0;				/* counter variable */
	struct cdll *temp_cdll = NULL;		/* pointer of cdll type */

	temp_cdll = *cdll_start;

	if (temp_cdll != NULL) {
		while(1) {
			++count;
			if (temp_cdll->next_ptr == *cdll_start)
				break;
			temp_cdll = temp_cdll->next_ptr;
		}

	}
	printf("Total Number of List:- %d\n", count);
	
	return count;	
}
