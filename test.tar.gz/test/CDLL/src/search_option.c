/*
	Function for Search option
*/

#include<cdll.h>

int search_option(struct cdll **cdll_start)
{
	int choice = 0;			/* int varible for choice*/
	
	int max = 1;			/* int variable for max option */
	int min = 2;			/* int variable for min option */
	
        while (1) {

	printf("Search operation\n");
	printf("1. Search for a value in the list\n");
	printf("2. Search for a value in the system of lists\n");
	printf("3. Maximum in a list\n");
        printf("4. Maximum in a system\n");
        printf("5. Minimum in a list\n");
        printf("6. Minimum in system\n");
	printf("7. Return to Main Menu\n");
	printf("Enter Choice\n");
	
	scanf("%d", &choice);

	switch(choice) {
	
	case 1:	search_in_list(cdll_start);	
		break;

	case 2:	search_in_system(cdll_start);
		break;
	
	case 3:	max_min_in_list(cdll_start, max);	
		break;

	case 4:	max_min_in_system(cdll_start, max);	
		break;

	case 5:	max_min_in_list(cdll_start, min);
		break;
	
	case 6:	max_min_in_system(cdll_start, min);
		break;
	
	case 7:	return(0);

	}

	}
}


