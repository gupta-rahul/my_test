/*
	Function for Inserting item at beginining in List 
*/

#include<cdll.h>

void insert_list_beg(struct cdll **cdll_start)
{

	int list_num;			/* int variable for list number */
	int count = 0;			/* counter Variable */
	int flag = 0;			/* flag variable */

        struct cdll *cdll_start_ptr = NULL;	/* cdll Start address */
        struct list *list_start_ptr = NULL;	/* list start Address */

	struct cdll *temp_cdll = NULL;		/* For traversing cdll */
	struct list *temp_list = NULL;		/* For Traversing List */
	struct list *temp_list1 = NULL;		/* For Traversing List */		
	
	struct list *temp_list_ptr = NULL;	/* For Adding New Element in List */

	if ((temp_list_ptr = (struct list *)malloc(sizeof(struct list))) == NULL)
		printf("Memory Allocation Failed in Insert List Beg\n");

	
	cdll_start_ptr = *cdll_start;
	list_start_ptr = cdll_start_ptr->list_ptr;
	
	temp_cdll = *cdll_start;
		
enter:	printf("Enter the List Number\n");
	scanf("%d", &list_num);
	
	printf("Enter the Element\n");
	scanf("%d", &temp_list_ptr->info);
        
	/* getting list from System */
	while(1) {
                ++count;
		if (count == list_num) {
                        flag = 1;
                        break;
                }
                if (temp_cdll->next_ptr == *cdll_start)
                        break;
                temp_cdll = temp_cdll->next_ptr;
        }



        temp_list = temp_cdll->list_ptr;

			
	if (flag == 0) {
		printf("List is not present....Enter Valid List \n");
		temp_cdll = *cdll_start;
		count = 0;
		goto enter;	
	}

	/* inserting nodes in list  */
      if (temp_list == NULL) {
                temp_list_ptr->next_ptr = temp_list_ptr;
		temp_list_ptr->prev_ptr = temp_list_ptr;
		temp_cdll->list_ptr = temp_list_ptr;
        } else {
                temp_list1 = temp_list->prev_ptr;
                temp_list1->next_ptr = temp_list_ptr;
                temp_list_ptr->next_ptr = temp_list;
		temp_list_ptr->prev_ptr = temp_list1;
		temp_list->prev_ptr = temp_list_ptr;
                temp_cdll->list_ptr = temp_list_ptr;
        }	

}
