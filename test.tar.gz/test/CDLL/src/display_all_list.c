/*
	Function for Displaying All Node in System
*/

#include<cdll.h>

void display_all_list(struct cdll **cdll_start)
{

	int count = 0;				/* counter Variable */
	struct cdll *temp_cdll_ptr = NULL;
	struct cdll *temp_cdll = NULL;

	struct list *temp_list_ptr = NULL;
	struct list *temp_list = NULL;
	
	temp_cdll_ptr = *cdll_start;
	temp_cdll = *cdll_start;
	
	if (temp_cdll_ptr == NULL)
	printf("Nothing to Display\n");
	
	/*Displaying all Node */        
	while(1) {
                temp_list_ptr = temp_cdll->list_ptr;
                temp_list = temp_cdll->list_ptr; 
        	++count;
		if (temp_list_ptr != NULL) {
	        	printf("List Number:- %d\n", count);
			while(1) {
                		printf("info - %d\n", temp_list_ptr->info);
				if (temp_list_ptr->next_ptr == temp_list)
        	                break;
        			temp_list_ptr = temp_list_ptr->next_ptr;
			}
		}		
                if (temp_cdll->next_ptr == *cdll_start)
                        break;
                temp_cdll = temp_cdll->next_ptr;
        }
}
