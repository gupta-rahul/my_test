/*
	Function for deleting entire System 
*/

#include<cdll.h>

int delete_entire_system(struct cdll **cdll_start)
{
        int j;					/*int variable for loop */
        int i;					/* int variable for Loop */
        int total_list_no;			/* int variable for total number of list in system */
	int list_num;                           /* int variable for list number */
        int item;                               /* int variable for item to delete */
        int list_size;                          /* int variable for size of list */
        int count = 0;                          /* counter variable */
        int count1 = 0;                         /* counter variable */
        int flag = 0;                           /* flag variable */
        int flag1 = 0;                          /* flag variable */

        struct cdll *cdll_start_ptr = NULL;     /* cdll Start address */
        struct list *list_start_ptr = NULL;     /* list start Address */

        struct cdll *temp_cdll = NULL;          /* For traversing cdll */
        struct cdll *temp_cdll1 = NULL;          /* For traversing cdll */
	struct list *temp_list = NULL;          /* For Traversing List */
        struct list *temp_list1 = NULL;         /* For Traversing List */

        cdll_start_ptr = *cdll_start;
        list_start_ptr = cdll_start_ptr->list_ptr;

        temp_cdll = *cdll_start;
	
	*cdll_start = NULL;

	total_list_no = total_list(&temp_cdll);
	printf("Total Number of List in System :- %d\n", total_list_no);

	for (i = 0; i < total_list_no; i++) {
		temp_list = temp_cdll->list_ptr;
		
	if (temp_list != NULL) {
			list_size = node_count(temp_list);
		        printf("Nodes deleted in list :- %d\n", list_size);
	
		        for (j = 0; j < list_size; j++) {
        		        temp_list1 = temp_list->next_ptr;
                		free(temp_list);
                		temp_list = temp_list1;
	        	}
		}
		
		temp_cdll1 = temp_cdll->next_ptr;
		free(temp_cdll);
		temp_cdll = temp_cdll1;
	}
}
