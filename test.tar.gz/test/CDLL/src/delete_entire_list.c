/*
	Function for Deleting Entire List 
*/

#include<cdll.h>

int delete_entire_list(struct cdll **cdll_start)
{
	int i;					/* Int variable for loop */
	int list_num;                           /* int variable for list number */
        int item;                               /* int variable for item to delete */
        int list_size;                          /* int variable for size of list */
        int count = 0;                          /* counter variable */
        int count1 = 0;                         /* counter variable */
        int flag = 0;                           /* flag variable */
        int flag1 = 0;                          /* flag variable */

        struct cdll *cdll_start_ptr = NULL;     /* cdll Start address */
        struct list *list_start_ptr = NULL;     /* list start Address */

        struct cdll *temp_cdll = NULL;          /* For traversing cdll */
        struct list *temp_list = NULL;          /* For Traversing List */
        struct list *temp_list1 = NULL;         /* For Traversing List */

        cdll_start_ptr = *cdll_start;
        list_start_ptr = cdll_start_ptr->list_ptr;

        temp_cdll = *cdll_start;

        printf("Enter the List Number\n");
        scanf("%d", &list_num);
	
	/* Getting List for Searxhig */

	while(1) {
                ++count;
                if (count == list_num) {
                        flag = 1;
                        break;
                }
                if (temp_cdll->next_ptr == *cdll_start)
                        break;
                temp_cdll = temp_cdll->next_ptr;
        }

	temp_list = temp_cdll->list_ptr;
        temp_list1 = temp_cdll->list_ptr;
	temp_cdll->list_ptr = NULL;

        if (flag == 0) {
                printf("List is not present....Enter Valid List \n");
                temp_cdll = *cdll_start;
                count = 0;
                return 0;
        }

	/* Checking whether the LIst is Empty or Not */
	if (temp_list == NULL) {
		printf("List is Empty.....");
		exit(1);
	}

	list_size = node_count(temp_list);
		
	printf("Size of List - %d\n", list_size);
	
	for (i = 0; i < list_size; i++) {
		temp_list1 = temp_list->next_ptr;
		free(temp_list);
		temp_list = temp_list1;
	}

}
