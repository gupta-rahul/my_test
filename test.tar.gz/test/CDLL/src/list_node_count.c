/*
	Function for Counting node in List 
*/


#include<cdll.h>


int node_count(struct list *list_start)
{
	int count = 0;				/* counter variable */
	struct list *temp_list = NULL;		/* pointer of struct list type */

	temp_list = list_start;

	if (temp_list != NULL) {
	while(1) {
		++count;
		if (temp_list->next_ptr == list_start)
			break;
		temp_list = temp_list->next_ptr;
	}
	}

	printf("Total Number of Node in  List:- %d\n", count);
	
	return count;	
}
