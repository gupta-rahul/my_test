/*
	Main Function 
*/

#include<cdll.h>

int main(void)
{

	struct cdll *cdll_start = NULL;			/* Pointer of struct cdll type */
	struct list *list_start = NULL;			/* pointer of struct list type */

        int choice = 0;					/* int variable for choice */

	while (1) {
	printf("\tCDLL\n");
	printf("1. Creation of Lists\n");
	printf("2. Insert operations\n");
	printf("3. Delete operations\n");
	printf("4. Search operation\n");
	printf("5. Display operations\n");
	printf("6. Exit	\n");
	printf("7. Total Number of List\n");
        printf("Enter Choice\n");
	
        scanf("%d", &choice);

        switch(choice) {

	case 1:	create_option(&cdll_start);
		break;

	case 2:	insert_option(&cdll_start);
		break;

	case 3:	delete_option(&cdll_start);
		break;

	case 4:	search_option(&cdll_start);
		break;

	case 5: display_option(&cdll_start);
		break;

	case 6:	delete_entire_system(&cdll_start);
		exit(1);

	case 7:	total_list(&cdll_start);
			break;

	}

	}
	return 0;
}
