/*
	Function for right rotation 
*/
#include<rb.h>

void right_rotation(struct rb **root)
{
	printf("right Rotataion is getting Called \n");
	
	struct rb * temp_ptr = NULL;
	
	temp_ptr = (*root)->right_child;
	
	if (temp_ptr != NULL) {
		printf("in right rotation call  - %p\n", temp_ptr);
		(*root)->right_child = temp_ptr->left_child;
		temp_ptr->left_child = *root;
		*root = temp_ptr;
	}

}
