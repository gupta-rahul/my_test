/*
	Funtion for Displaying RED_BLACK tree in preorder
*/

#include<rb.h>

int display_preorder(struct rb **root)
{

	struct rb *temp_ptr = NULL;			/* pointer of Struct rb type */
	
	if (*root == NULL) {
		return 0;
	}
	
	temp_ptr = *root;
		
//	printf("Item:- %d  Color:- %d\n", temp_ptr->info, temp_ptr->color);
	printf("\tItem:- %d\n", temp_ptr->info, ((temp_ptr->color == 0)?printf("Color- red"):printf("color- black")));
	display_preorder(&temp_ptr->left_child);
	display_preorder(&temp_ptr->right_child);
	
	return 0;
}
