/*
	Main Function
*/

#include<rb.h>

int main(void)
{
        struct rb *root = NULL;
	struct rb *parent = NULL;
        int choice = 0;	
	int item;

        while (1) {
        printf("\t RED_BLACK Tree\n");
        printf("1. Insert operations in RED_BLACK\n");
        printf("2. Display operationsin RED_BLACK\n");
	printf("3. Exit \n");
        printf("Enter Choice\n");

        scanf("%d", &choice);

        switch(choice) {

        case 1:	printf("Enter the item\n");
		scanf("%d", &item);
		insert_node(&root, item,&parent);
                break;

	case 2:	display_option(&root);
                break;

        case 3: exit(1);
	
	
	}

	}

	return 0;

}
