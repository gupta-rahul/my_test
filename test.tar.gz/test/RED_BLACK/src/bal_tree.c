#include<rb.h>


void bal_tree(struct rb **root)
{

	struct rb *temp_root = NULL;		/* pointer of struct rb */
	
	struct rb *temp_parent = NULL;		/* pointer of struct rb */
	
	struct rb *temp_uncle = NULL;

	printf("Entering balance Tree Funtion \n");
	temp_root = *root;
	temp_parent = (*root)->parent;

	if (temp_root != NULL && temp_parent != NULL && temp_parent->parent != NULL) { 
		if (temp_root->color == temp_parent->color) {
			printf("When node and Parent is having same color\n");
	
		if (temp_parent->parent->right_child != NULL) {
			 temp_uncle = (*root)->parent->parent->right_child;
		
		if (temp_parent->color == temp_uncle->color) {
			printf("Add_of_par:- %p\t Add_of_uncle:- %p\n", temp_parent, temp_uncle);
			printf("Both uncle and Parent is of same color \n");
			if (temp_parent->color == red) {
				printf("Color changing from red to Black\n");
				temp_parent->color = black;
				temp_uncle->color = black;
			} else if (temp_parent->color == black) {
				printf("Color changing from Black to Red\n");
				temp_parent->color = red;
				temp_uncle->color = red;
			}						
			}	
	} else {
			printf("Nested else part\n");
			(*root)->parent->parent->left_child = (*root)->parent->right_child;
			(*root)->parent->right_child = (*root)->parent->parent;
			//(*root)->parent->parent = (*root)->parent;
		}	
	
	} else {
	
	if (temp_root->color == temp_parent->color) {
		if ((temp_root == temp_parent->left_child) && (temp_parent == temp_parent->parent->left_child))
			printf("LL");
		else
			printf("RR");

	}
	}
	}
}
