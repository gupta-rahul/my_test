/*
	Funtion for Displaying RED_BLACK tree in postorder
*/

#include<rb.h>

int display_postorder(struct rb **root)
{

	struct rb *temp_ptr = NULL;			/* pointer of Struct rb type */
	
	if (*root == NULL) {
		return 0;
	}
	
	temp_ptr = *root;
		
	display_postorder(&temp_ptr->left_child);
	display_postorder(&temp_ptr->right_child);
	printf("Item:- %d\n", temp_ptr->info);
	return 0;
}
