/*
	Function for left Rotation 
*/

#include<rb.h>

void left_rotation(struct rb **root)
{

	printf("Left Rotataion is getting Called \n");

        struct rb * temp_ptr = NULL;

        temp_ptr = (*root)->left_child;
	printf("Address of Root in rotation:- %p\n", *root);

	if (temp_ptr != NULL) {
        	printf("in right rotation call  - %p\n", temp_ptr);
		(*root)->left_child = temp_ptr->right_child;
        	temp_ptr->right_child = *root;
	        *root = temp_ptr;
	}
	printf("Address of Root in rotation after process:- %p\n", *root);
}
