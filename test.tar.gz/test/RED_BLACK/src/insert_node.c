/*
	Funtion for Inserting Node in REB_BLACK tree
*/

#include<rb.h>

int insert_node(struct rb **root, int item, struct rb **parent)
{

	struct rb **temp = NULL;			/* pointer of Struct rb type */
	struct rb *temp_rb = NULL;			/* pointer of Struct rb type */
	
	temp = root;

        if (*temp == NULL) {
		/* Memory Allocation */
		if ((temp_rb = (struct rb *)malloc(sizeof(struct rb))) == NULL)
			printf("---->Memory Allocation faile in Create_rb funtion\n");
		/* getting the node Value */
		printf("Address of new Node:- %p\n", temp_rb);
		temp_rb->info = item;
		if(*parent != NULL)
			temp_rb->color = red;
		else
			temp_rb->color = black;
			
		temp_rb->parent = *parent;
		temp_rb->left_child = NULL;
	        temp_rb->right_child = NULL;
		*root = temp_rb;
	} else if ((*temp)->info > item) {
		insert_node((&(*temp)->left_child), item, root);
		bal_tree((&(*temp)->left_child));
	} else {
		insert_node((&(*temp)->right_child), item, root);
		bal_tree((&(*temp)->right_child));
		}
}
