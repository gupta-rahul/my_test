/*
	Function for right left Rotation 
*/

#include<rb.h>

void right_left_rotation(struct rb **root)
{

	printf("right Left Rotataion is getting Called \n");

        if (*root != NULL) {
                printf("in right left rotation call  - %p\n", *root);
		left_rotation(&(*root)->right_child);
		right_rotation(root);
	
        }
}

