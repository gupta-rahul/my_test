/*
	Funtion for Displaying Red Black tree in preorder
*/

#include<rb.h>

int display_inorder(struct rb **root)
{

	struct rb *temp_ptr = NULL;			/* pointer of Struct rb type */
	
	if (*root == NULL) {
		return 0;
	}
	
	temp_ptr = *root;
	display_inorder(&temp_ptr->left_child);
	printf("\tItem:- %d\t Node Add:- %p\tParent:- %p\n", temp_ptr->info, temp_ptr, temp_ptr->parent, ((temp_ptr->color == 0)?printf("Color- red"):printf("color- black")));
	display_inorder(&temp_ptr->right_child);
	
	return 0;
}
