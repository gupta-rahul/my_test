#ifndef _RB_H_
#define _RB_H_

#include<stdio.h>
#include<stdlib.h>

struct rb {
	enum {red,black} color;
	struct rb *left_child;
	struct rb *right_child;
	struct rb *parent;
	int info;
};
		
void bal_tree(struct rb **root);			/* Function for Balancing tree */

#endif
