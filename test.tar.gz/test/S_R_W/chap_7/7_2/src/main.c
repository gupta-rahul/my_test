#include<header.h>

int main(int argc, char *argv[])
{

    char *str = "This is RAHUL\n";

    printf(str);
    
//    printf
    return 0;
}
