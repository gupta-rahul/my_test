#include<header.h>

int main(int argc, char *argv[])
{

    int i;
    int j = 0;

    for (i = 1; i < argc; i++) {
    
        while (*(*(argv + i) + j) != '\0') {
            //printf("%c ",*(*(argv + i) + j));
            printf("%c",case_convert(*(*(argv + i) + j)));
                    j++;
            }
        j = 0;
        printf(" ");
    }
    printf("\n");

    return 0;
}
