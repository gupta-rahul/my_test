#include<header.h>

char case_convert(char ch)
{
    char c;
    
    if ((ch >= 'A') && ('Z' <= ch)){
        c = ch - 32;
    } else {
        c = ch + 32;
    }
    return c;
}

