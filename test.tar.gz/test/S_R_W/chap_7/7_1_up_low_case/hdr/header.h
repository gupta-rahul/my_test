#ifndef _header_h_
#define _header_h_

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#endif
