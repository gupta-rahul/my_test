#include<hdr.h>


void insert(struct node ** head)
{
    struct node * temp = NULL;

    struct node *temp_ptr = NULL;

    temp = (struct node *)malloc(sizeof(struct node));

    temp_ptr = *head;

    printf("Enter the polynomial value's\n");
    
    printf("Coeff:\n");
    
    scanf("%d", &temp->coeff );
    
    printf("X:\n");
    
    scanf("%d",  &temp->x);
    
    printf("Y:\n");
    
    scanf("%d",  &temp->y);
    
    printf("Z:\n");
    
    scanf("%d",  &temp->z);
    
    if (temp_ptr == NULL) {
        *head = temp;
    } else {
        while ( temp_ptr->next != NULL)
            temp_ptr = temp_ptr->next;
            temp_ptr->next = temp;
    }
        temp->next = NULL;
}
