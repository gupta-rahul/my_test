#include<hdr.h>


void swap_node(struct node **head, struct node *nod1, struct node *nod2)
{
    struct node *node1 = NULL;
    struct node *node1_prev = NULL;
    struct node *node2 = NULL;
    struct node *node2_prev = NULL;
    struct node *temp = NULL;

    node1 = *head;
    node1_prev = *head;
    node2 = *head;
    node2_prev = *head;

    while (node1 != nod1) {
        node1_prev = node1;
        node1 = node1->next;
    }

    while (node2 != nod2) {
        node2_prev = node2;
        node2 = node2->next;
    }

    if (node1 != *head) {
        temp = node2->next;
        node2->next = node1->next;
        node1->next = temp;
        node2_prev->next = node1;
        node1_prev->next = node2;
    } else {
        temp = node2->next;
        node2->next = node1->next;
        node1->next = temp;
        node2_prev->next = node1;
        *head = node2;
    }
}
