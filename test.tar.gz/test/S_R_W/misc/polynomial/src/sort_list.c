#include<hdr.h>

void sort_list(struct node **head)
{
    int max;
    struct node *max_ptr = NULL;
    struct node *temp_ptr1 = NULL;
    struct node *temp_ptr2 = NULL;

    temp_ptr1 = *head;
    temp_ptr2 = *head;

    while (temp_ptr1 != NULL) {   
        printf("While 1\n");
        max = temp_ptr1->x + temp_ptr1->y + temp_ptr1->z;
        max_ptr = temp_ptr1;
        temp_ptr2 = temp_ptr1->next;
        while (temp_ptr2 != NULL) {
            printf("While 2\n");
            if (max < (temp_ptr2->x + temp_ptr2->y + temp_ptr2->z)) {
                max = temp_ptr2->x + temp_ptr2->y + temp_ptr2->z;
                max_ptr = temp_ptr2;
            }
            temp_ptr2 = temp_ptr2->next;
        }

        printf("swaping ..\n");
        if (temp_ptr1 != max_ptr) {
            printf("temp_ptr:- %p\tmax_ptr:- %p\n", temp_ptr1, max_ptr);
            swap_node(head, temp_ptr1, max_ptr);
        }
        printf("swaping done..\n");
        temp_ptr1 = temp_ptr1->next;
    }
    printf("Endof Sortlist\n");
}
