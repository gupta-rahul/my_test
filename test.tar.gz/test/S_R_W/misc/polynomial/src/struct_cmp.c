#include<hdr.h>

int struct_cmp(struct node *var1, struct node *var2)
{
    
   if (var1->x == var2->x && var1->y == var2->y && var1->z == var2->z) 
       return 1;
   else 
    return 0;
}
