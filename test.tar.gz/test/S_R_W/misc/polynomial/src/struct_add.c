#include<hdr.h>

void struct_add(struct node **head)
{
    struct node * var1 = NULL;
    struct node * var2 = NULL;

    struct node *prev = NULL;

    var1 = *head;
    var2 = *head;

    while (var1 != NULL) {
            prev = var1;
            var2 = var1->next;              /* Node After next head */
        while (var2 != NULL) {
            if (struct_cmp(var1, var2)) {
                prev->next = var2->next;
                var1->coeff = var1->coeff + var2->coeff;
                free(var2);
             }
            var2 = var2->next;
        }
        var1 = var1->next;
    }
    
}
