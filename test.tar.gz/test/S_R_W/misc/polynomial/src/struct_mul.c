#include<hdr.h>

void struct_mul(struct node **master_node, struct node *node1, struct node * node2)
{
    struct node * temp = NULL;
    
    struct node * temp_ptr = NULL;

    temp_ptr = *master_node;

    temp = (struct node *)malloc(sizeof(struct node));

    temp->coeff = node1->coeff * node2->coeff;
    temp->x = node1->x + node2->x;
    temp->y = node1->y + node2->y;
    temp->z = node1->z + node2->z;

    if (temp_ptr == NULL) {
        *master_node = temp;
    } else {
        while (temp_ptr->next != NULL)
                temp_ptr = temp_ptr->next;
        temp_ptr->next = temp;
    }

    temp->next = NULL;
}
