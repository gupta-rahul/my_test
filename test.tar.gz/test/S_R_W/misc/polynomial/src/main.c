#include<hdr.h>


int main(void)
{
    int i;

    int element;

    struct node *master_head = NULL;

    struct node * head1 = NULL;
    
    struct node * head2 = NULL;

    struct node * temp = NULL;
    
    struct node * temp1 = NULL;

    printf("Enter the length of list 1\n");
    scanf("%d", &element);

    for (i = 0; i < element; i++)
        insert(&head1);
    
    printf("Enter the length of list 2\n");
    scanf("%d", &element);
    
    for (i = 0; i < element; i++)
        insert(&head2);

    temp = head1;

    while (temp != NULL) {
        printf("coeef:- %d    x:-  %d  y:-  %d  z:- %d\n", temp->coeff, temp->x, temp->y, temp->z);
        temp = temp->next;
        }
    
    temp = head2;

    while (temp != NULL) {
        printf("coeef:- %d    x:-  %d  y:-  %d  z:- %d\n", temp->coeff, temp->x, temp->y, temp->z);
        temp = temp->next;
    }

    temp = head1;

    temp1 = head2;
    
    while (temp != NULL) {
        while (temp1 != NULL) {
            struct_mul(&master_head, temp, temp1);
            temp1 = temp1->next;
        }
        temp1 = head2;
        temp = temp->next;
    }

    struct_add(&master_head);
    
    temp = master_head;
    
    while (temp != NULL) {
        if (temp->coeff != 0)
            printf("coeef:- %d", temp->coeff);
        if (temp->x != 0)
            printf(" x^%d", temp->x);
        if(temp->y != 0)
            printf(" y^%d", temp->y);
        if (temp->z != 0)
            printf(" z^%d", temp->z);
        printf("\n");
        temp = temp->next;
    }
    
    sort_list(&master_head);

    temp = master_head;
    
    while (temp != NULL) {
        if (temp->coeff != 0)
            printf("coeef:- %d", temp->coeff);
        if (temp->x != 0)
            printf(" x^%d", temp->x);
        if(temp->y != 0)
            printf(" y^%d", temp->y);
        if (temp->z != 0)
            printf(" z^%d", temp->z);
        printf("\n");
        temp = temp->next;
    }


    return 0;
}
