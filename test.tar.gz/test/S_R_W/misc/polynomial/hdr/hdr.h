#ifndef _HDR_H_
#define _HDR_H_

#include<stdio.h>
#include<stdlib.h>

struct node {
    int coeff;
    int x;
    int y;
    int z;
    struct node *next;
};

void insert(struct node ** head);                       /*Function for inserting node */

void sort_list(struct node **head);                     /*Function for sorting list */

void struct_add(struct node **head);                    /*Function for adding structure variable */

void struct_mul(struct node **master_node, struct node *node1, struct node * node2);        /*Function for multiplication*/

void swap_node(struct node **head, struct node *nod1, struct node *nod2);                   /*Function for swapping*/

#endif
