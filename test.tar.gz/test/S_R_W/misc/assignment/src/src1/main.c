#include<stdio.h>
#include<string.h>

int main(int argc, char *argv[])
{

    char c;
    FILE *fd_src;
    FILE *fd_des;
    
    if (!strcmp(argv[1], ">>")) {                   /* Appening to file from Command line */
        if (!(fd_src = fopen(argv[2], "a+"))) 
            printf("failed opening File...\n");
        fseek(fd_src,0, SEEK_END);
        while ((c = getc(stdin)) != EOF) {
                putc(c, fd_src);
        } 
    } else if (!strcmp(argv[1], ">")) {             /* copying to file from Command line */
        if (!(fd_src = fopen(argv[2], "w+")))
            printf("failed opening File...\n");

        while ((c = getc(stdin)) != EOF) {
            putc(c, fd_src);
        }
    } else if (!strcmp(argv[2], ">>")) {            /* Appending From File */
        if (!(fd_src = fopen(argv[1], "r+")))
            printf("failed opening File...\n");

        if (!(fd_des = fopen(argv[3], "a+")))
            printf("Failed opening Second File...\n");
        
        fseek(fd_des, 0, SEEK_END);

        while ((c = getc(fd_src)) != EOF) {
            putc(c, fd_des);
        }
    } else if (!strcmp(argv[2], ">")){              /*Copying From File */
        if (!(fd_src = fopen(argv[1], "r+")))
            printf("failed opening File...\n");

        if (!(fd_des = fopen(argv[3], "w+")))
            printf("Failed opening Second File...\n");
        
        while ((c = getc(fd_src)) != EOF) {
            putc(c, fd_des);
        }
    }

    return 0;
}
