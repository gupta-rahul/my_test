#include<stdio.h>
#include<stdlib.h>



int main(int argc, char *argv[])
{
    char c;

    FILE *fd_src;
    
    FILE *fd_des;


    if (!(fd_src = fopen(argv[1], "r+")))
            printf("failed opening File...\n");

    if (!(fd_des = fopen(argv[3], "w+")))
        printf("Failed opening Second File...\n");

   while ((c = getc(fd_src)) != EOF) {
        putc(c, fd_des);
   }

   fclose(fd_src);
   fclose(fd_des);

   return 0;
}
