#include<stdio.h>
#include<stdlib.h>



int main(int argc, char *argv[])
{
    FILE *fd;

    char c;

    if (!(fd = fopen(argv[2],"a+")))
        printf("failed opeinging....\n");

    fseek(fd, 0, SEEK_END);

    while ((c = getc(stdin)) != EOF) {
        putc(c, fd);
    }

    fclose(fd);

    return 0;
}
