#ifndef _calculator_h_
#define _calculator_h_

#include<stdio.h>
#include <ctype.h>
#include <stdlib.h>
#define MAXOP   100
#define NUMBER '0' 
#define MAXVAL 100
#define BUFSIZE 100

int getop(char []);
void push(double);
double pop(void);
int getch(void);
void ungetch(int);

#endif
