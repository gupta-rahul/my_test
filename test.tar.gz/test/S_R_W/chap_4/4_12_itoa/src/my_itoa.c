#include<itoa.h>


void my_itoa(int number, char *str)
{
    static int i = 0;

    if (number < 0) {
        number = -number;
        *str++ = '-';
    }
    
    if (number / 10)
        my_itoa((number / 10) , str);
    
    *(str + i++) = ((number  % 10) + '0');
    
}
