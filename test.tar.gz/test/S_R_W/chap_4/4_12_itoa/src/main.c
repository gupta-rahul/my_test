#include<itoa.h>


int main(void)
{
    int number;
    
    char *string = (char *)malloc(sizeof(char) * 50);

    printf("Enter the Number\n"); 
    scanf("%d", &number);

    my_itoa(number,string);

    printf("string:- %s\n", string);

    return 0;
}
