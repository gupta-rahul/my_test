#ifndef _itoa_h_
#define _itoa_h_

#include<stdlib.h>
#include<stdio.h>

void my_itoa(int number, char *string);

#endif
