#include<rev_str.h>


int main(void)
{
    char *str = NULL;

    char *temp_str = NULL;

    str = (char *)malloc(sizeof(char) * 256);

    printf("Enter the string\n");
    
    fgets(str,256,stdin);
    
    printf("String entered:- %s\n", str);
    
    temp_str = str;

    while (*temp_str != '\n') {
        temp_str++;
    }
    
    *temp_str = '\0';
    
    --temp_str;

    rev_str(str, temp_str);

    printf("Reversed String:- %s\n", str);

    return 0;
}
