#include<rev_str.h>


void rev_str(char *front_str, char *end_str)
{
    char temp;

        temp = *front_str;
        *front_str = *end_str;
        *end_str = temp;

    if (front_str < end_str)
        rev_str(++front_str, --end_str);
}
