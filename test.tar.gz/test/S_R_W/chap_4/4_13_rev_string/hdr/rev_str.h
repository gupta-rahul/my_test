#ifndef _str_rev_h_
#define _str_rev_h_

#include<stdio.h>
#include<stdlib.h>

void rev_str(char *front_str, char *end_str);

#endif
