#ifndef _scientific_not_h_
#define _scientific_not_h_

#include<stdio.h>
#include<math.h>

double my_atof(char *str);      /*Function for handling scientific notation */

#endif
