#include<scientific_not.h>

double my_atof(char *str)
{

    int i;
    
    char operator;

    int count = 0;

    int flag = 0;

    int raise_pow = 0;

    long double val = 0;

    long long power = 0;
    
    while (*str != 'e') {
        if (*str != '.' || flag == 1) {
                if (*str != '.')
                        val = val * 10 + (*str - '0');
                    if (flag == 1)
                        count++;
        } else if (*str == '.')
                flag = 1;
        str++;
    }
    
    while (*++str != '\0') {
            if (*str != '+' && *str != '-')
                    power = power * 10 + (*str - '0');
            else
                    operator = *str;
    }

    if (operator == '+')
            raise_pow = power - count;
    else if (operator == '-')
            raise_pow = -(count + power);

        power = 1;

        for (i = 0; i < abs(raise_pow); i++)
            power = power * 10;

        if (raise_pow < 0)
            val = val / power;
        else
            val = val * power;

    return val;
}
