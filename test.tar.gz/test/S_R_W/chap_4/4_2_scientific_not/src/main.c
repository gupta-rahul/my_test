/*
 *  Program to handle scientific Notation
 * */

#include<scientific_not.h>


int main(int argc, char *argv[])
{
    char *str = NULL;
    
    long double value;
    
    str = argv[1];

    value = my_atof(str);

    printf("value:- %Lf\n", value);

    return 0;
}
