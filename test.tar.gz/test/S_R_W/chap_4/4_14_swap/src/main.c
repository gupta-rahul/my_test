#include<swap.h>

#define swap(type,x,y)  {   type temp;   \
                            temp = x;    \
                            x = y;       \
                            y = temp;    }
                            
int main(void)
{
    int x = 100;

    int y = 200;
    
    printf("x:- %d\t y:- %d\n", x, y);

    swap(int, x, y);

    printf("x:- %d\t y:- %d\n", x, y);

    return 0;
}
