#include<stdio.h>

extern int a;

int main()
{
    int a = 19;
    return 0;
}
