/*Funtion to find the Right most index of substring in string*/

/*
 * string1 =  main_string
 * string2 = sub_string
 */
 
int strindex(char string1[], char string2[])
{
    int i;
    int j;
    int k;
    int position = -1;

        for (i = 0; string1[i] != '\0'; i++) {
            for (j = i, k = 0; (string2[k] != '\0') && (string1[j] == string2[k]); j++,k++);
           if (k > 0 && string2[k] == '\0') {
            position = i;
           }
        }
        
    return position;
}
