/* Program to find the Right most index of substring in string*/

#include<strindex.h>

int main(void)
{
    int result; /* variable for storing result */

    char main_string[] = "This is Global Edge software limited in Global Global Village"; 
    char sub_string[] = "Global";
 
    result = strindex(main_string, sub_string);

    if (result != -1)
        printf("Index in Main stirng :- %d\n", result);
    else 
        printf("Substring not found.\n");

    return 0;
}
