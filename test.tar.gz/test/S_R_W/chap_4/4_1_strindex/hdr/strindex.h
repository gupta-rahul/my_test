#ifndef _STRINDEX_H_
#define _STRINDEX_H_

#include<stdio.h>

int strindex(char string1[], char string2[]);

#endif
