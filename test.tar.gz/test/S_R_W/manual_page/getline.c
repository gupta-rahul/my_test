#include<stdio.h>
#include<string.h>
#include<stdlib.h>


int main(void)
{
    char *string = NULL;//(char*)malloc(sizeof(char) * 256);

    int size = 256;

    printf("Enter the String:- \n");

    getline (&string, &size, stdin);

    printf("Entered string:- %s\n", string);

    printf("Size:- %d\n", size);

    return 0;
}   
