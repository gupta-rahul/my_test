#ifndef _strncmp_h_
#define _strncmp_h_

#include<stdio.h>
#include<stdlib.h>

int str_n_cmp(char *s, char *t, int n);


#endif
