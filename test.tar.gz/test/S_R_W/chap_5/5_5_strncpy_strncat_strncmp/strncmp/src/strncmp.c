#include<strncmp.h>

int str_n_cmp(char *s, char *t, int n)
{

    while ((*s == *t) && n-- > 0) {
        s++;
        t++;
    }

    if (n == 0) {
             return 0;
    }
    else {
        return (*s - *t);
    }
}

