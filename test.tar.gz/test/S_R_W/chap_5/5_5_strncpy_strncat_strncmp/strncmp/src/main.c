#include<strncmp.h>


int main(void)
{
    int num;

    int result;

    char *s = NULL;

    char *t = NULL;

    s = (char *)malloc(sizeof(char) * 256);
    
    t = (char *)malloc(sizeof(char) * 256);

    printf("Enter Src\n");

    fgets(s, 256, stdin);

    printf("Enter Des\n");
    
    fgets(t, 256, stdin);

    printf("Enter the number of byte to copy\n");

    scanf("%d", &num);

    result = str_n_cmp(s, t, num);
    
    printf("result:- %d\n", result);

    return 0;
}
