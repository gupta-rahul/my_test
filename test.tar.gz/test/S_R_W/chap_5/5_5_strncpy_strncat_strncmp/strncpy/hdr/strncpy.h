#ifndef _strncpy_h_
#define _strncpy_h_

#include<stdio.h>
#include<stdlib.h>

void str_n_cpy(char *s, char *t, int n);


#endif
