#include<strncpy.h>

void str_n_cpy(char *s, char *t, int n)
{
    
    while (((*s++ = *t++) != '\n') && (n-- > 1));


    while (*s++ != '\n');

        *s = '\0';

}
