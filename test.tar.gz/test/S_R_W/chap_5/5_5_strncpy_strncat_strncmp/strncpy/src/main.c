#include<strncpy.h>


int main(void)
{
    int num;

    char *s = NULL;

    char *t = NULL;

    s = (char *)malloc(sizeof(char) * 256);
    
    t = (char *)malloc(sizeof(char) * 256);

    printf("Enter Src\n");

    fgets(s, 256, stdin);

    printf("Enter Des\n");
    
    fgets(t, 256, stdin);

    printf("Enter the number of byte to copy\n");

    scanf("%d", &num);

    str_n_cpy(s, t, num);
    
    printf("s:- %s\n", s);

    return 0;
}
