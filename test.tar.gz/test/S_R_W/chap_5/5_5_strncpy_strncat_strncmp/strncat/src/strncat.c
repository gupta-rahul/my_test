#include<strncat.h>

void str_n_cat(char *s, char *t, int n)
{
    
    int len;
    
    while (*s++ != '\n');
    
    --s;
    
    while (((*s++ = *t++) != '\n') && (n-- > 0));
        
        *s = '\0';

}
