#ifndef _strncat_h_
#define _strncat_h_

#include<stdio.h>
#include<stdlib.h>

int str_len(char *str);

void str_n_cat(char *s, char *t, int n);

#endif
