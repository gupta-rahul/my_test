/*
 * Write a program entab that replaces strings of blanks by the minimum number
 * of tabs and blanks to achieve the same spacing. Use the same tab stops as for detab . When
 * either a tab or a single blank would suffice to reach a tab stop, which should be given
 * preference?
 */

#include<stdio.h>

int main()
{
	char ch;
	char str[256];
	int i = 0;
	int flag = 0;
	int count = 0;

	while ((ch = getchar()) != EOF) {
		if ((ch == ' ')) {
			str[i] = ch;
			flag = 1;
			++count;
			if (count == 4 && flag == 1) {
				i = i - 7;
				str[i] = '\t';
				count = 0;
			}
			++i;
		} else if (ch == '\n') {
			break;
		} else {
			str[i] = ch;
			flag == 0;
			count = 0;				
			++i;
		}
	}
	str[i] = '\0';
	printf("\n%s\n",str);
	i = 0;
	while ( str[i] != '\0') {
	printf("%c  - %d\n",str[i],i);
	//printf("%c",str[i]);
		++i;
	}
	printf("\n");
	return 0;
}

