/*
 * Write a program detab that replaces tabs in the input with the proper number
 * of blanks to space to the next tab stop. Assume a fixed set of tab stops, say every n columns.
 * Should n be a variable or a symbolic parameter?
 */

#include<stdio.h>
#define TAB_SIZE 4

int main()
{
	int i;
	int count = 0;
	char ch;

	while ((ch = getchar()) != EOF) {
		if (ch == '\t') {
			for ( i = 0; i < (TAB_SIZE - count); i++) {
			printf("-");
			}
			count = 0;
		} else {
			putchar(ch);
			++count;	
		}
	}			
	return 0;
}

