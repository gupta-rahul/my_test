#include<hdr.h>

int main(void)
{
    int year;

    int month;

    int day;

    printf("Enter the Year, month and day\n");

    scanf("%d%d%d", &year, &month, &day);

    printf("Days:- %d\n", day_of_year(year, month, day));

    month_day(2015, 211, &month, &day);

    printf("Month:- %d\t Day:- %d\n", month, day);

    return 0;
}
