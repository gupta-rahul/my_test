/* day_of_year: set day of year from month & day */

#include<hdr.h>

int day_of_year(int year, int month, int day)
{
    int i, leap;

    leap = year%4 == 0 && year%100 != 0 || year%400 == 0;
    
    if (((month < 1) || (month > 12)) || (0 > day || day > daytab[leap][month] ))
        return -1;
    
    for (i = 1; i < month; i++)
        day += *(*(daytab + leap) + i);
    
    return day;
}
