#ifndef _strend_h_
#define _strend_h_

#include<stdio.h>
#include<stdlib.h>

int str_len(char *str);

int str_end(char *temp_s, char *temp_t);

#endif
