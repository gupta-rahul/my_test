#include<strend.h>

int str_end(char *temp_s, char *temp_t)
{
    int i;

    int len;

    len = str_len(temp_t);

    while (*temp_s++ != '\n');

    --temp_s;

    while (*temp_t++ != '\n');

    --temp_t;

    while ((*temp_s-- == *temp_t--) && len-- >= 0);

    if (len > 0)
        return 0;
    else 
        return 1; 
}
