#include<strend.h>

int str_len(char *str)
{
    int len = 0;

    while (*str++ != '\n')
        len++;

    return len;
}
