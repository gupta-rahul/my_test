#include<strcat.h>


void str_cat(char *des, char *src)
{
    while (*des++ != '\n');
    
    --des;
    
    while ((*des++ = *src++) != '\n');
    
    *des = '\0';
}
