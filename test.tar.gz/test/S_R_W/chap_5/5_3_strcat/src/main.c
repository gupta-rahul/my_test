#include<strcat.h>

int main(void)
{

    char *src = NULL;

    char *des = NULL;

    src = (char *)malloc(sizeof(char) * 256);
    
    des = (char *)malloc(sizeof(char) * 256);

    printf("Enter Source\n");

    fgets(src, 256, stdin);

    printf("Enter Destination\n");
    
    fgets(des, 256, stdin);

    str_cat(des, src);

    printf("strcat string:- %s\n", des);


    return 0;
}
