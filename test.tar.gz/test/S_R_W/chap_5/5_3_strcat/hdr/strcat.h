#ifndef _strcat_h_
#define _strcat_h_

#include<stdio.h>
#include<stdlib.h>

void str_cat(char *des, char *src);

#endif

