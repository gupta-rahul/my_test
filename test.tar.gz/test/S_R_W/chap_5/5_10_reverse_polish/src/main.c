#include<rev_pol.h>

int main(int argc, char *argv[])
{
    int i = 1;

    int op2;

    for ( i = 0; i < argc - 1; i++) {
        if (atoi(argv[i+1]) != 0) {
            push(atoi(argv[i + 1]));
        } else {
            switch (*argv[i + 1]) {

                case '+': 
                    push(pop() + pop());
                    break;
                case '*':
                    push(pop() * pop());
                    break;
                case '-':
                    op2 = pop();
                    push(pop() - op2);
                    break;
                case '/':
                    op2 = pop();
                    if (op2 != 0)
                        push(pop() / op2);
            }
        }
    }
    
    printf("Result:- %d\n", pop());

    return 0;
}
