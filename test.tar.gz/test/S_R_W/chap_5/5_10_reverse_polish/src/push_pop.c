#include<rev_pol.h>


void push(int item)
{
    if (top > SIZE)
        printf("stack Full\n");
    else 
        stack[top++] = item;
}

int pop(void)
{
    if ( top < 0)
        printf("Stack empty\n");
    else 
        return stack[--top];
}
