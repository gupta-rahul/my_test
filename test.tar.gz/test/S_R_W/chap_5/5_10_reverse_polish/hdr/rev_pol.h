#ifndef _rev_pol_h_
#define _rev_pol_h_
#define SIZE 50

#include<stdio.h>
#include<stdlib.h>

int stack[SIZE];

static int top = 0;

void push(int item);

int pop(void);

#endif
