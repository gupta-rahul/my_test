/* pipe()  creates  a pipe, a unidirectional data channel that can be used for interprocess communication.  
 * The array pipefd is used  to return  two  file  descriptors  referring to the ends of the pipe. 
 * pipefd[0] refers to the read end of the pipe.  
 * pipefd[1] refers to the  write  end of the pipe. 
 * Data written to the write end of the pipe is buffered by the kernel until it is read from the read  end of the pipe */

#include<string.h>
#include<stdio.h>
#define SIZE 256

int main(void)
{
	int pipe_fd[2];

	char string1[256];
	char string2[256];

	int result;

	result = pipe(pipe_fd);

	printf("pipe_output:- %d\n", result);

	if (fork()) {
		while (1) { 
			printf("write:- \t");
			fgets(string1, sizeof(string1), stdin);
			write(pipe_fd[1],string1, sizeof(string1));
			bzero(string1,sizeof(string1));
		}
	} else {
		while(1) {
			read(pipe_fd[0],string2,sizeof(string1));
			printf("read:- %s\n", string2);
		}
	}

	return 0;
}
