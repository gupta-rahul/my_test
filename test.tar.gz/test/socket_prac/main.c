#include <sys/types.h>      
#include <netinet/in.h>
#include <sys/socket.h>
#include <linux/ip.h>
#include<linux/if_ether.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<net/if.h>
#include<linux/udp.h>
#include<linux/tcp.h>
#define SIZE 1024
#define SERVERPORT 5000

char *check_protocol(int protocol);
void ip_hdr_display(struct iphdr *ip_hdr);
void eth_hdr_display(struct ethhdr *eth_hdr);
void tcp_hdr_display(struct tcphdr *tcp_hdr);
void udp_hdr_display(struct udphdr *udp_hdr);


int main(int agc, char *argv[])
{
    char *opt = NULL;

    opt = "eth0";

    char *buffer = NULL;

    int len;

    buffer = (char *)malloc(SIZE);

    int sock_fd;

    struct iphdr *ip_hdr;
    struct ethhdr *eth_hdr;
    struct udphdr *udp_hdr;
    struct tcphdr *tcp_hdr;

    struct sockaddr_in serveraddr;

    sock_fd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_IP));

    perror("socket");

    setsockopt(sock_fd, SOL_SOCKET , SO_BINDTODEVICE, opt, sizeof(opt));

    perror("setsockopt");

    while (1) {
        len = recvfrom(sock_fd, buffer, SIZE, 0, NULL, NULL);

        if (len < 0)
            perror("recvfrom");

        printf("%d bytes read\n", len);

        ip_hdr = (struct iphdr *)(buffer + sizeof(struct ethhdr));
        eth_hdr = (struct ethhdr *)buffer;

        ip_hdr_display(ip_hdr);
        eth_hdr_display(eth_hdr);
    
        if (ip_hdr->protocol == 6) {
            tcp_hdr = (struct tcphdr *)(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr));
            tcp_hdr_display(tcp_hdr);
        } else if (ip_hdr->protocol == 17){
            udp_hdr = (struct udphdr *)(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr));
            udp_hdr_display(udp_hdr);
        }
    }

    close(sock_fd);

    return 0;
}

char *check_protocol(int protocol)
{
    switch(protocol) {

        case 6: return "TCP Protocol";
            break;

        case 17: return "UDP Protocol";
            break;
    }
}

void ip_hdr_display(struct iphdr *ip_hdr)
{   
    printf("*******************IP_HEADER****************************\n");
    printf("ihl:- %d\n", ip_hdr->ihl);
    printf("version:- %d\n", ip_hdr->version);
    printf("tos:- %d\n", ip_hdr->tos);
    printf("tot_len:- %d\n", ip_hdr->tot_len);
    printf("id:- %d\n", ip_hdr->id);
    printf("frag_off:- %d\n", ip_hdr->frag_off);
    printf("ttl:- %d\n", ip_hdr->ttl);
    printf("protocol:- %s\n", check_protocol(ip_hdr->protocol));
    printf("check:- %d\n", ip_hdr->check);
    printf("saddr:- %s\n", inet_ntoa(ip_hdr->saddr));
    printf("daddr:- %s\n", inet_ntoa(ip_hdr->daddr));
}

void eth_hdr_display(struct ethhdr *eth_hdr)
{
    printf("*******************ETH_HEADER***************************\n");
    printf("Dest_eth_addr:- %.2x-%.2x-%.2x-%.2x-%.2x-%.2x \n", eth_hdr->h_dest[0], eth_hdr->h_dest[1], 
            eth_hdr->h_dest[2], eth_hdr->h_dest[3], eth_hdr->h_dest[4], eth_hdr->h_dest[5]);   /* destination eth addr */
    printf("Srce_eth_addr:- %.2x-%.2x-%.2x-%.2x-%.2x-%.2x \n", eth_hdr->h_source[0], eth_hdr->h_source[1],
            eth_hdr->h_source[2], eth_hdr->h_source[3], eth_hdr->h_source[4], eth_hdr->h_source[5]); /* sorce eth addr */
    printf("Packet_Id_field:- %d\n", eth_hdr->h_proto);        /* packet type ID field */
}

void udp_hdr_display(struct udphdr *udp_hdr)
{
    printf("*******************UDP_HEADER***************************\n");
    printf("source:- %d\n", udp_hdr->source);
    printf("dest:- %d\n",  udp_hdr->dest);
    printf("length:- %d\n", udp_hdr->len);
    printf("Check:- %d\n",  udp_hdr->check);
    printf("\n\n");
}

void tcp_hdr_display(struct tcphdr *tcp_hdr)
{
    printf("*******************TCP_HEADER*****************************\n");
    printf("source:- %d\n", tcp_hdr->source);
    printf("dest:- %d\n", tcp_hdr->dest);
    printf("seq:- %d\n", tcp_hdr->seq);
    printf("ack_seq:- %d\n", tcp_hdr->ack_seq);
    printf("doff:- %d\n", tcp_hdr->doff);
    //printf("res1:-%d\n", tcp_hdr->resl);
    printf("cwr:- %d\n", tcp_hdr->cwr);
    printf("ece:- %d\n", tcp_hdr->ece);
    printf("urg:- %d\n", tcp_hdr->urg);
    printf("ack:- %d\n", tcp_hdr->ack);
    printf("psh:- %d\n", tcp_hdr->psh);
    printf("rst:- %d\n", tcp_hdr->rst);
    printf("syn:- %d\n", tcp_hdr->syn);
    printf("fin:- %d\n", tcp_hdr->fin);
    printf("window:- %d\n", tcp_hdr->window);
    printf("check:- %d\n", tcp_hdr->check);
    printf("urg_ptr:- %d\n", tcp_hdr->urg_ptr);
    printf("\n\n");
}
