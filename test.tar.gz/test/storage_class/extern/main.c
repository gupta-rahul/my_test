#include<stdio.h>

#define MAX 20

//#undef MAX

int a = 250;

struct abc {

    int aa;
    int bb;
}test;

extern fun();

int main(void)
{
    typedef int a_int ;
    

    printf("MAX:- %d\n", MAX);


    test.aa = 1000;
    test.bb = 2000;
    fun();

    printf("A in main:- %d\n", a);

    printf("sizeof(char) == %d\n", sizeof(char));
    printf("sizeof(short) == %d\n", sizeof(short));
    printf("sizeof(int) == %d\n", sizeof(int));
    printf("sizeof(long) == %d\n", sizeof(long));
    printf("sizeof(float) == %d\n", sizeof(float));
    printf("sizeof(double) == %d\n", sizeof(double));
    printf("sizeof(long double) == %d\n", sizeof(long double));
    printf("sizeof(long long) == %d\n", sizeof(long long));



    return 0;
}
