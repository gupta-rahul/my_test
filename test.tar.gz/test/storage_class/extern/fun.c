#include<stdio.h>




void fun(void)
{
    extern a;

    extern struct abc test;
    
  //printf("value of aa:- %d\n", test.aa);
  //  printf("value of bb:- %d\n", test.bb);


    printf("This is A from other File :- %d\n", a);

    a = 2500000;


}
