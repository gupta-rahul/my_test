#include<stdio.h>


int main(void)
{
    typedef int usr_int, *ptr_int;

    usr_int aa = 123;

    ptr_int pp = &aa;

    typedef usr_int abc;

    //abc tt = 561;

    //typeof(abc) rahu;

    //printf("rahu :- %d\n", rahu);
    
    //printf("tt:- %d\n", tt);

    printf("variable:- %d\n", aa);

    printf("Pointer:- %d\n", *pp);

    return 0;
}
