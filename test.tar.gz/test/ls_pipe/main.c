#include<stdio.h>
#include<stdlib.h>
#include<string.h>


int main(int argc, char *argv[])
{

    int i = 0;

    FILE *fd;

    char *buffer = (char *)malloc(sizeof(char) * 512);
    char *temp_buffer = buffer;
    
    char *string = NULL;
    char *temp_string = NULL;
    
    char c;

    FILE *ptr = popen("ls > file.txt", "w");
    
    wait(NULL);

    string = argv[1];

    temp_string = argv[1];

    printf("String to find:- %s\n",string );

    fd = fopen ("file.txt", "r+");
    
    while ((c = getc(fd)) != EOF) {
        if (*temp_string == c) {
                *temp_buffer++ = c;
                temp_string++;
        } else if ((*temp_string != c ) && (*temp_string != '\0')) {
              //printf("%c",c);
                temp_string = string;
                temp_buffer = buffer;
        } else if (*temp_string == '\0'){
            //while(((c = getc(fd)) != ' ' ) || ((c = getc(fd)) != '\n') || ((c = getc(fd)) != '\t') )
                //*temp_buffer++ = c;
                *temp_buffer++ = ' ';
            temp_buffer = buffer;
        }
//      printf("buffer:- %s\n",buffer);
    }

//    *temp_buffer = '\0';
    if (strlen(buffer) != 0)
        printf("result :- %s\n", buffer);
    else
        printf("file Not Found....\n");
    
    close(fd);
    
    unlink("file.txt");    
    return 0;
}
