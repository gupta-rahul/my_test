#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<signal.h>


void display()
{
	printf("This is Just A display Function in Child\n");
	//getchar();
// 	sleep(10);
	kill(getppid(),SIGUSR1);
	printf("Sending signal to parent \n");
}

void dis()
{
	printf("Got signal from Child....\n");	
}

int main(void)
{
	int res;
	
	if(fork()) {
		signal(SIGUSR1,dis);		
		printf("Waiting for Child to Finish Work...\n");
		pause();
		printf("Child Finish Work...\n");
	} else {
		display();
	}

	return 0;
}
