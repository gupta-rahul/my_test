#include<stdio.h>
#include<stdlib.h>
#include<signal.h>

void dis(int sig)
{
	printf("\nSignal is Invoked....:- %d\n", sig);
}

int main()
{
	signal(SIGINT,dis);
	
	pause();

	return 0;
}
