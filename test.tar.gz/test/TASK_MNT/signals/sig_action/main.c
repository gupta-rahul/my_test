#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<signal.h>

void func(int sig, siginfo_t *siginfo, void *context)
{
	printf("This is Func Functioni in Child.....:- %d\n", sig);
	printf("si_signo :- %d\n", siginfo->si_signo);    /* Signal number */
	printf("si_code :- %d\n", siginfo->si_code);    /* Signal code */
	printf("si_pid :- %d\n", siginfo->si_pid);      /* Sending process ID */
        printf("si_uid :- %d\n", siginfo->si_uid );      /* Real user ID of sending process */
        printf("si_status :- %d\n", siginfo->si_status);   /* Exit value or signal */
	printf("si_utime :- %lu\n", siginfo->si_utime);    /* User time consumed */
        printf("si_stime :- %lu\n", siginfo->si_stime);    /* System time consumed */
	printf("si_value :- %u\n", siginfo->si_value);    /* Signal value */

}

void foo()
{
	printf("This is Foo....\n");
}
int main(void)
{

	int res;
	struct sigaction sig;

	//sig.sa_handler = foo;

	sig.sa_sigaction = func;

	sig.sa_flags = SA_SIGINFO;
	
	if (fork()) {
		sigaction(SIGUSR1, &sig, NULL);	
		printf("Waiting for Child to Finish Work....\n");
		pause();
		printf("Child execution finished...\n");
	} else {
		printf("child pid:- %d\n", getpid());
		sleep(4);
		kill(getppid(),SIGUSR1);	
	}	

	return 0;
}
