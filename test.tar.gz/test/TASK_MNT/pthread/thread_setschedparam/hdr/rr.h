#ifndef _RR_H_
#define _RR_H_

#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<string.h>
#include<linux/sched.h>
#include<unistd.h>

int status;

void* func1(void *arg);

char *inhertsched_check(int inherit);

char *policy_check(int pol);

char *detach_status(int state);

#endif


