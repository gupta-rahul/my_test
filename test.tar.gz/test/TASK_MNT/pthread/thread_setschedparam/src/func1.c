#include<rr.h>

void *func1(void *arg)
{
	 int i;
         for (i = 0; i < 1; i++) {
                 printf("%s Executing..\n", (char *)arg);
         }

         status = 500;
         return &status;
}


