#include<rr.h>

int status;

int main(void)
{
	int res;
	char *th1 = "Thread 1";	
	int *retval1 = NULL;
	int *attr_state = NULL;
	int detach_state;
	int policy ;
	int priority_max;
	int priority_min;
	int inheritsched;	

	/*creating variable of type sched_param*/	
	struct sched_param get_param;
	struct sched_param set_param;
	
	/* setting priority */
	set_param.sched_priority = 1;

	/**/	
	attr_state = (int *)malloc(sizeof(int));
		
	/**/	
	retval1 = (int *)malloc(sizeof(int));

	/* Creating thread handler */	
	pthread_t thd1;

	/* Creating thread attribute */	
	pthread_attr_t thd1_attr;
	
	/* initializing  the  thread attributes*/	
	pthread_attr_init(&thd1_attr);
	
	/* getting scheduling parameter of the created thread */	
	pthread_attr_getschedparam(&thd1_attr, &get_param);
	
	/* getting scheduling policy attribute of the thread */	
	pthread_attr_getschedpolicy(&thd1_attr, &policy);
	
	/* getting inherit-scheduler attribute of the thread */	
	pthread_attr_getinheritsched(&thd1_attr, &inheritsched);

	/* getting Detach state of the thread  */
	pthread_attr_getdetachstate(&thd1_attr,&detach_state );

	printf("\nDetach:- %s\n", detach_status(detach_state));
	
	printf("schedparam:- %d\n", get_param.sched_priority);
	
	printf("schedpolicy:- %s\n", policy_check(policy));
	
	printf("Inherit sched :- %s\n", inhertsched_check(inheritsched));

	/* setting detach Status of the thread */	
	pthread_attr_setdetachstate(&thd1_attr, PTHREAD_CREATE_JOINABLE);

	/*getting detach status of the thread */	
	pthread_attr_getdetachstate(&thd1_attr,&detach_state );

	printf("\nDetach:- %s\n", detach_status(detach_state));
	
        /*Setting inherit-scheduler attribute of the thread */
        //pthread_attr_setinheritsched(&thd1_attr, PTHREAD_INHERIT_SCHED);
        pthread_attr_setinheritsched(&thd1_attr, PTHREAD_EXPLICIT_SCHED);
	
	/* Creating Thread */
	pthread_create(&thd1, &thd1_attr, &func1, (void *)th1);
	
	pthread_setschedparam(thd1, SCHED_FIFO ,&get_param);

	printf("schedparam after Setting:- %d\n", set_param.sched_priority);
	
	printf("schedpolicy after Setting:- %s\n", policy_check(policy));
	
	printf("Inherit sched after Setting :- %s\n", inhertsched_check(inheritsched));
	
	res = pthread_join(thd1,(void **)&retval1);
	
	printf("Thread 1 Execution Finished\n");

	printf("Return Value:- %d\n\n", *retval1);

	pthread_exit(NULL);
	
	return 0;

}
