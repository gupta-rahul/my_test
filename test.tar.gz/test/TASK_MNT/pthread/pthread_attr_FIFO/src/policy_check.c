#include<rr.h>

char *policy_check(int pol)
{
	switch (pol) {
 
         case SCHED_FIFO: return "SCHED_FIFO";
 
         case SCHED_RR: return "SCHED_RR";
 
         case SCHED_BATCH: return "SCHED_BATCH";
 
         case SCHED_IDLE: return "SCHED_IDLE";
 
         case SCHED_OTHER: return "SCHED_OTHER";
         }
 
}







