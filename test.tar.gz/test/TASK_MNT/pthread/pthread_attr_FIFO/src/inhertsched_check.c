#include<rr.h>

char *inhertsched_check(int inherit)
{
 
	switch (inherit) {

        case PTHREAD_INHERIT_SCHED: return "PTHREAD_INHERIT_SCHED";
 
        case PTHREAD_EXPLICIT_SCHED: return "PTHREAD_EXPLICIT_SCHED";
        
	 }
 
}



