#include<rr.h>

char *detach_status(int state)
{
 
         switch (state) {
 
         case PTHREAD_CREATE_DETACHED: return "PTHREAD_CREATE_DETACHED";
 
         case PTHREAD_CREATE_JOINABLE: return "PTHREAD_CREATE_JOINABLE";

	 }
 
}




