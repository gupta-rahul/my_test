#include<rr.h>

void *func1(void *arg)
{
	 int i;
         for (i = 0; i < 5; i++) {
                printf("%s Executing..\n", (char *)arg);
        	sleep(1); 
	}

         status = 500;
         return &status;
}


