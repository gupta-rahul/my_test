#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

void handler (int sig_num)
{
	printf("child ripped\n");
        wait(NULL);
}

int main()
{
        int seconds;
        char line[120];
        char message[64];
/*        if (SIG_ERR == signal(SIGCHLD, handler)) {
                perror ("signal :");
                exit (0);
        }
  */      
        while(1) {
                printf ("Alarm=");
                if (fgets (line, sizeof (line), stdin) == NULL) exit(0) ;
                if (strlen (line) <= 1) continue;
        
                if (sscanf (line, "%d %64[^\n]", &seconds, message) <2 ) {
                        printf(stderr, "Bad command\n");
                        return 0;
                }
                if (fork()) {
                
                }
                else {
                        sleep (seconds);
                        printf ("(%d) %s\n", seconds, message);
			exit(0);
                }
        }
}

