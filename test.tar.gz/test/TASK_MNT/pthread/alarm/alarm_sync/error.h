#ifndef _ERROR_H_
#define _ERROR_H_

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<errno.h>
#include<unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#endif
