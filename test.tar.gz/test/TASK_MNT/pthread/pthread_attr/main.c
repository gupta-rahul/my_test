#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<string.h>
#include <linux/sched.h>
#include<unistd.h>


int status;

char *policy_check(int pol);

char *inhertsched_check(int inherit);

char *detach_status(int state);

void* func1(void *arg)
{
	int i;
	for (i = 0; i < 1; i++) {
		printf("%s Executing..\n", (char *)arg);
	}
	
	status = 500;
	return &status;
}

int main(void)
{
	int res;
	char *th1 = "Thread 1";	
	int *retval1 = NULL;
	int *attr_state = NULL;
	int detach_state;
	int policy ;
	int priority_max;
	int priority_min;
	int inheritsched;	

	/*creating variable of type sched_param*/	
	struct sched_param get_param;
	struct sched_param set_param;
	
	/* setting priority */
	set_param.sched_priority = 1;

	/**/	
	attr_state = (int *)malloc(sizeof(int));
		
	/**/	
	retval1 = (int *)malloc(sizeof(int));

	/* Creating thread handler */	
	pthread_t thd1;

	/* Creating thread attribute */	
	pthread_attr_t thd1_attr;
	
	/* initializing  the  thread attributes*/	
	pthread_attr_init(&thd1_attr);
	
	/* getting scheduling parameter of the created thread */	
	pthread_attr_getschedparam(&thd1_attr, &get_param);
	
	/* getting scheduling policy attribute of the thread */	
	pthread_attr_getschedpolicy(&thd1_attr, &policy);
	
	/* getting inherit-scheduler attribute of the thread */	
	pthread_attr_getinheritsched(&thd1_attr, &inheritsched);

	/* getting Detach state of the thread  */
	pthread_attr_getdetachstate(&thd1_attr,&detach_state );

	printf("\nDetach:- %s\n", detach_status(detach_state));
	
	printf("schedparam:- %d\n", get_param.sched_priority);
	
	printf("schedpolicy:- %s\n", policy_check(policy));
	
	printf("Inherit sched :- %s\n", inhertsched_check(inheritsched));

	/* getting the maximum priority value*/	
	priority_max = sched_get_priority_max(policy);

	/* getting the minimum priority value*/	
	priority_min = sched_get_priority_min(policy);
	
	printf("priority_max:- %d\n", priority_max);
	
	printf("priority_min:- %d\n\n", priority_min);

	/* setting detach Status of the thread */	
	pthread_attr_setdetachstate(&thd1_attr, PTHREAD_CREATE_JOINABLE);

	/* Creating Thread */
//	pthread_create(&thd1, &thd1_attr, &func1, (void *)th1);

        /*Setting scheduling parameter of the created thread */
        pthread_attr_setschedparam(&thd1_attr, &set_param);

	/*Setting scheduling policy attribute of the thread */
        pthread_attr_setschedpolicy(&thd1_attr, SCHED_RR);
	
	/* getting scheduling policy attribute of the thread */	
	pthread_attr_getschedpolicy(&thd1_attr, &policy);
	
	/*getting detach status of the thread */	
	pthread_attr_getdetachstate(&thd1_attr,&detach_state );

	printf("\nDetach:- %s\n", detach_status(detach_state));
	
        /*Setting inherit-scheduler attribute of the thread */
        //pthread_attr_setinheritsched(&thd1_attr, PTHREAD_INHERIT_SCHED);
        //pthread_attr_setinheritsched(&thd1_attr, PTHREAD_EXPLICIT_SCHED);
	
    /* getting inherit-scheduler attribute of the thread */	
	pthread_attr_getinheritsched(&thd1_attr, &inheritsched);

	/* Creating Thread */
	pthread_create(&thd1, &thd1_attr, &func1, (void *)th1);
	
	printf("schedparam after Setting:- %d\n", set_param.sched_priority);
	
	printf("schedpolicy after Setting:- %s\n", policy_check(policy));
	
	printf("Inherit sched after Setting :- %s\n", inhertsched_check(inheritsched));
	
	res = pthread_join(thd1,(void **)&retval1);
	
	printf("Thread 1 Execution Finished\n");

	printf("Return Value:- %d\n\n", *retval1);

	pthread_exit(NULL);
	
	return 0;

}

char *policy_check(int pol)
{

	switch (pol) {
	
	case SCHED_FIFO: return "SCHED_FIFO";

	case SCHED_RR: return "SCHED_RR";

	case SCHED_BATCH: return "SCHED_BATCH";

	case SCHED_IDLE: return "SCHED_IDLE";

	case SCHED_OTHER: return "SCHED_OTHER";	
	}

}

char *inhertsched_check(int inherit)
{

	switch (inherit) {
	
	case PTHREAD_INHERIT_SCHED: return "PTHREAD_INHERIT_SCHED";

	case PTHREAD_EXPLICIT_SCHED: return "PTHREAD_EXPLICIT_SCHED";	
	}

}

char *detach_status(int state)
{

	switch (state) {
	
	case PTHREAD_CREATE_DETACHED: return "PTHREAD_CREATE_DETACHED";

	case PTHREAD_CREATE_JOINABLE: return "PTHREAD_CREATE_JOINABLE";	
	}

}
