#include<stdio.h>
#include <pthread.h>
#include<stdlib.h>
#include<string.h>


int status;

void* func1(void *arg)
{
	int i;
	for (i = 0; i < 5; i++) {
		printf(":- %s Executing..\n", (char *)arg);
		sleep(1);
	}
	
	status = 500;
	return &status;
}

int main(void)
{
	int res;
	char *th1 = "Thread 1";
	char *th2 = "Thread 2";
	int *retval1 = NULL;
	int *retval2 = NULL;
	retval1 = (int *)malloc(sizeof(int));
	retval2 = (int *)malloc(sizeof(int));
		
	pthread_t thd1;
	pthread_t thd2;
	
	pthread_create(&thd1, NULL, &func1, (void *)th1);
	pthread_create(&thd2, NULL, &func1, (void *)th2);

	res = pthread_join(thd1,(void **)&retval1);
	printf("Thread 1 Execution Finished\n");
	res = pthread_join(thd2,(void **)&retval2);
	printf("Thread 2 Execution Finished\n");


	printf("Return Value:- %d\n", *retval1);
	printf("Return Value:- %d\n", *retval2);
	pthread_exit(NULL);


}

