#include<stdio.h>
#include<fcntl.h>
#include<linux/ioctl.h>


//int a = 200;

int main(void)
{
	int a = 300; 
	int fd;
	char uBuffer[100];// = "character_device_driver";

         fd = open("/dev/char_dd", O_RDWR);
         if(fd < 0)
                 perror("Unable to open the device");
         else
                printf("File open successful : - %d\n", fd);

	if (vfork()) {
		if (ioctl(fd, getpid(), &a) == -1) {
      			perror("query_apps ioctl get");
		}
	} else {
	//	a = 500;
		
		if (ioctl(fd, getpid(), &a) == -1) {
      			perror("query_apps ioctl get");
		}
		exit(1);
	}	

         close(fd);

         return 0;
}
