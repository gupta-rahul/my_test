#include<stdio.h>
#include <pthread.h>
#include<stdlib.h>
#include<string.h>


pthread_cond_t cond_var = PTHREAD_COND_INITIALIZER;

typedef struct tag {
	pthread_mutex_t lock;
        int arr[100];
}my_struct_mutex;
 
my_struct_mutex data = {PTHREAD_MUTEX_INITIALIZER, 0};

int status;
int write_status = 0;

void* write(void *arg)
{
	int i;
	int result;
	
	result = pthread_mutex_lock(&data.lock);
	printf("%s start Executing...\n", (char*)arg);
	if (result < 0)
		printf("Mutex lock Failed in Write...\n");
	
	printf("Writing......\n");
	sleep(5);
	for (i = 0; i < 100; i++) {
		printf("x:-%d\t",i+1);
		data.arr[i] = i + 1;
	}
    write_status = 1;
	pthread_mutex_unlock(&data.lock);
	printf("\nThread 1 Completed Execution..\n");	
	status = 500;
	return &status;
}

void* read(void *arg)
{
	int i;
	int result;
	
	printf("Thread 2 Waiting For Resource to Free........\n");
	result = pthread_mutex_lock(&data.lock);
    while (write_status == 0)
        pthread_cond_wait(&cond_var, &data.lock);
    printf("%s start Executing...\n", (char *)arg);
	if (result < 0)
		printf("Mutex lock Failed in Read...\n");
	printf("Reading.....\n");
	for (i = 0; i < 100; i++) {
		printf("R:- %d\t", data.arr[i]);	
	}
	pthread_mutex_unlock(&data.lock);
	printf("\n");	
	
	status = 200;
	return &status;
}

int main(void)
{
	int res;
	char *th1 = "Thread 1";
	char *th2 = "Thread 2";
	int *retval1 = NULL;
	int *retval2 = NULL;
	retval1 = (int *)malloc(sizeof(int));
	retval2 = (int *)malloc(sizeof(int));
		
	pthread_t thd1;
	pthread_t thd2;
	
	pthread_create(&thd1, NULL, &write, (void *)th1);
	pthread_create(&thd2, NULL, &read, (void *)th2);

	res = pthread_join(thd1,(void **)&retval1);
	printf("Thread 1 Execution Finished\n");
	res = pthread_join(thd2,(void **)&retval2);
	printf("Thread 2 Execution Finished\n");


	printf("Return Value:- %d\n", *retval1);
	printf("Return Value:- %d\n", *retval2);
	pthread_exit(NULL);


}

