#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>

int main()
{
	int status;
	int var = 90;
	/*Creating mutex */
	pthread_mutex_t my_mutex;
	
	/*Initializing mutex */
	my_mutex = {PTHREAD_MUTEX_INITIALIZER };
		
	/* Acquiring Lock */
	status = pthread_mutex_lock(&my_mutex);
	if (status < 0)
		printf("Mutex lock Aquiring Failed\n");
	var = 500;
	
	/*Releasing Lock */
	status = pthread_mutex_unlock(&my_mutex);
	if (status < 0)
		printf("Mutex lock Releasing Failed\n");

	printf("Variable Value:- %d\n", var);

	return 0;

}
