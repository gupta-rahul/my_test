#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>

typedef struct tag {
	pthread_mutex_t my_mutex;
	int var;
}my_struct_mutex;


my_struct_mutex  data = {PTHREAD_MUTEX_INITIALIZER, 0};

int main()
{
	int status;
	
	/* Acquiring Lock */
	status = pthread_mutex_lock(&(data.my_mutex));
	if (status < 0)
		printf("Mutex lock Aquiring Failed\n");
	
	data.var = 500;
	
	/*Releasing Lock */
	status = pthread_mutex_unlock(&data.my_mutex);
	if (status < 0)
		printf("Mutex lock Releasing Failed\n");

	printf("Variable Value:- %d\n", data.var);

	return 0;

}
