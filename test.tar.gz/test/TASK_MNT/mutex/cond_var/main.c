#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>

int status;

typedef struct {
    pthread_mutex_t my_lock;
 
    pthread_cond_t my_cond_var;

    int info;

}thd;

thd data = {PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER,  0};


void* fun(void * ptr)
{
    printf("thread_1 is Excuting......\n");
    int i;
    pthread_mutex_lock(&data.my_lock);
//    pthread_cond_wait(&data.my_cond_var, &data.my_lock);
    for (i = 0; i< 5; i ++) {
        printf("This is Func.....\n");
            sleep(1);
    }
    pthread_mutex_unlock(&data.my_lock);
}

void* fun2(void * ptr1)
{

    int i;
    pthread_mutex_lock(&data.my_lock);
  //  pthread_cond_signal(&data.my_cond_var);
    for (i = 0; i< 5; i ++) {
        printf("This is Func2.....\n");
            sleep(1);
    }
    pthread_mutex_unlock(&data.my_lock);

}

int main(void)
{
    pthread_t   thd1;
    pthread_t   thd2;
   
    pthread_create(&thd1, NULL, fun, NULL); 
    pthread_create(&thd2, NULL, fun2, NULL); 

    pthread_exit(NULL);

	return 0;
}
