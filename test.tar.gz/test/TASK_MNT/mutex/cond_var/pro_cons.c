#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>

int status;

typedef struct {
    pthread_mutex_t my_lock;
 
    pthread_cond_t my_cond_produce;
    pthread_cond_t my_cond_consume;
       
}thd;

int cs = 0;

thd data = {PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER,  0};


void *producer1(void * ptr)
{
    int i;
    while (1) {
    pthread_mutex_lock(&data.my_lock);
//    printf("%s Waiting for Consuming.......\n", (char *)ptr);
    while (cs != 0) {
        printf("Waiting for Coosumer to Consume data...\n");
        pthread_cond_wait(&data.my_cond_consume, &data.my_lock);
    }
    
    printf("%s is Excuting......\n", (char *)ptr);
    sleep(2);
    cs = 1;
    printf("%s produced data..%d\n", (char *)ptr, cs);
    pthread_cond_signal(&data.my_cond_produce);
    pthread_mutex_unlock(&data.my_lock);
    }
}
/*
void *producer2(void * ptr)
{
    int i;
    pthread_mutex_lock(&data.my_lock);
   // printf("%s Waiting for Consuming.......\n", (char *)ptr);
    while (cs != 0)
        pthread_cond_wait(&data.my_cond_consume, &data.my_lock);
    
    printf("%s is Excuting......\n", (char *)ptr);
    sleep(2);
    cs = 2;
    printf("%s produced data..%d\n", (char *)ptr, cs);
    pthread_cond_signal(&data.my_cond_produce);
    pthread_mutex_unlock(&data.my_lock);
}
*/

void *consumer1(void * ptr1)
{
    int i;
    while (1) {
    pthread_mutex_lock(&data.my_lock);
    while (cs == 0) {
        printf("%s Waiting for Producer to produce data...\n", (char *)ptr1);
        pthread_cond_wait(&data.my_cond_produce, &data.my_lock);
    }
    printf("%s is Excuting.& data is consumed :- %d.....\n", (char *)ptr1, cs);
    sleep(5);
    cs = 0; 
    pthread_cond_signal(&data.my_cond_consume);
    pthread_mutex_unlock(&data.my_lock);
    }
}

void *consumer2(void * ptr1)
{
    int i;
    while (1) {
    pthread_mutex_lock(&data.my_lock);
    while (cs == 0) {
            printf("%s Waiting for Producer to produce data...\n", (char *)ptr1);
            pthread_cond_wait(&data.my_cond_produce, &data.my_lock);
    }
    printf("%s is Excuting.& data is consumed :- %d.....\n", (char *)ptr1, cs);
    sleep(5);
    cs = 0;
    pthread_cond_signal(&data.my_cond_consume);
    pthread_mutex_unlock(&data.my_lock);
    }
}

int main(void)
{
    char *thd1 = "producer 1";
    char *thd2 = "producer 2";
    char *thd3 = "consumer 1";
    char *thd4 = "consumer 2";

    pthread_t   thread_prod1;
    pthread_t   thread_prod2;
    pthread_t   thread_cons1;
    pthread_t   thread_cons2;
   
    pthread_create(&thread_prod1, NULL, producer1, (void *)thd1); 
    pthread_create(&thread_cons1, NULL, consumer1, (void *)thd3); 
//    pthread_create(&thread_prod2, NULL, producer2, (void *)thd2); 
    pthread_create(&thread_cons2, NULL, consumer2, (void *)thd4); 

    pthread_exit(NULL);

	return 0;
}
