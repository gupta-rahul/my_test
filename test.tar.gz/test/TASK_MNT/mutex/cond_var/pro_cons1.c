#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>

int status;

typedef struct {
    pthread_mutex_t my_lock[3];
    pthread_cond_t my_cond_produce;
    pthread_cond_t my_cond_consume;
       
}thd;

int cs[3] = {0};

thd data = {{PTHREAD_MUTEX_INITIALIZER, PTHREAD_MUTEX_INITIALIZER, PTHREAD_MUTEX_INITIALIZER}, PTHREAD_COND_INITIALIZER};

void *producer1(void * ptr)
{
    int i;
    while (1) {
    //pthread_mutex_lock(&data.my_lock[0]);
    while (cs[0] != 0) {
        printf("%s Waiting for Consumer to Consume data...\n", (char *)ptr);
        sleep(2);
//        pthread_cond_wait(&data.my_cond_consume, &data.my_lock);
    }
    if (!pthread_mutex_lock(&data.my_lock[0]))
        printf("producer 1 Acquired Lock..\n");
    printf("%s is Excuting......\n", (char *)ptr);
    sleep(2);
    cs[0] = 1;
    printf("%s produced data..%d\n", (char *)ptr, cs[0]);
//    pthread_cond_signal(&data.my_cond_produce);
    if (!pthread_mutex_unlock(&data.my_lock[0]))
            printf("Producer 1 Release Lock..\n");
    }
}

void *producer2(void * ptr)
{
    int i;
    while (1) {
    //pthread_mutex_lock(&data.my_lock[1]);
    while (cs[1] != 0) {
        printf("%s Waiting for Consumer to Consume data...\n", (char *)ptr);
        sleep(2);
//        pthread_cond_wait(&data.my_cond_consume, &data.my_lock);
    }
    if (!pthread_mutex_lock(&data.my_lock[1]))
        printf("producer 2 Acquired Lock..\n");
    printf("%s is Excuting......\n", (char *)ptr);
    sleep(2);
    cs[1] = 2;
    printf("%s produced data..%d\n", (char *)ptr, cs[1]);
//    pthread_cond_signal(&data.my_cond_produce);
    if (!pthread_mutex_unlock(&data.my_lock[1]))
        printf("producer 2 Release Lock..\n");
    }
}

void *producer3(void * ptr)
{
    int i;
    while (1) {
    //pthread_mutex_lock(&data.my_lock[1]);
    while (cs[2] != 0) {
        printf("%s Waiting for Consumer to Consume data...\n", (char *)ptr);
        sleep(2);
//        pthread_cond_wait(&data.my_cond_consume, &data.my_lock);
    }
    if (!pthread_mutex_lock(&data.my_lock[2]))
        printf("producer 2 Acquired Lock..\n");
    printf("%s is Excuting......\n", (char *)ptr);
    sleep(2);
    cs[2] = 3;
    printf("%s produced data..%d\n", (char *)ptr, cs[2]);
//    pthread_cond_signal(&data.my_cond_produce);
    if (!pthread_mutex_unlock(&data.my_lock[2]))
        printf("producer 3 Release Lock..\n");
    }
}

void *consumer1(void * ptr1)
{
    int i;
    int status;
    while (1) {
    for (i = 0; i < 3; i++) {
    if (cs[i] != 0) {
    if ((!pthread_mutex_lock(&data.my_lock[i]))) {
        printf("consumer 1 Acquired lock %d\n", i+1);
//    while ((cs[i] == 0)) {
  //      printf("%s Waiting for Producer to produce data...\n", (char *)ptr1);
//        pthread_cond_wait(&data.my_cond_produce, &data.my_lock);
//    }
    printf("%s is Excuting.& data is consumed :- %d...from Producer %d..\n", (char *)ptr1, cs[i], i+1);
    cs[i] = 0; 
    sleep(2);
//    pthread_cond_signal(&data.my_cond_consume);
    //}
    if (!pthread_mutex_unlock(&data.my_lock[i]))
            printf("Consumer 1 Release the Lock\n");
    }
    }
    }
    }
}

void *consumer2(void * ptr1)
{
    int i;
    int status;
    while (1) {
    for (i = 0; i < 3; i++) {
    if (cs[i] != 0) {
    if ((!pthread_mutex_lock(&data.my_lock[i]))) {
        printf("consumer 2 Acquired lock %d\n", i+1);
//    while ((cs[i] == 0)) {
  //      printf("%s Waiting for Producer to produce data...\n", (char *)ptr1);
//        pthread_cond_wait(&data.my_cond_produce, &data.my_lock);
//    }
    printf("%s is Excuting.& data is consumed :- %d...from Producer %d..\n", (char *)ptr1, cs[i], i+1);
    cs[i] = 0; 
    sleep(2);
//    pthread_cond_signal(&data.my_cond_consume);
    //}
    if (!pthread_mutex_unlock(&data.my_lock[i]))
            printf("Consumer 2 Release the Lock\n");
    }
    }
    }
    }
}

/*
void *consumer3(void * ptr1)
{
    int i;
    while (1) {
//    pthread_mutex_lock(&data.my_lock);
    while (cs[1] == 0) {
            printf("%s Waiting for Producer to produce data...\n", (char *)ptr1);
//            pthread_cond_wait(&data.my_cond_produce, &data.my_lock);
    }
    printf("%s is Excuting.& data is consumed :- %d.....\n", (char *)ptr1, cs[1]);
    sleep(2);
    cs[1] = 0;
//    pthread_cond_signal(&data.my_cond_consume);
//    pthread_mutex_unlock(&data.my_lock);
    }
}
*/
int main(void)
{
    char *thd1 = "producer 1";
    char *thd2 = "producer 2";
    char *thd3 = "consumer 1";
    char *thd4 = "consumer 2";
    char *thd5 = "producer 3";
    char *thd6 = "consumer 3";

    pthread_t   thread_prod1;
    pthread_t   thread_prod2;
    pthread_t   thread_prod3;
    pthread_t   thread_cons1;
    pthread_t   thread_cons2;
    pthread_t   thread_cons3;
   
    pthread_create(&thread_prod1, NULL, producer1, (void *)thd1); 
    pthread_create(&thread_cons1, NULL, consumer1, (void *)thd3); 
    pthread_create(&thread_prod2, NULL, producer2, (void *)thd2); 
    pthread_create(&thread_cons2, NULL, consumer2, (void *)thd4); 
    pthread_create(&thread_prod3, NULL, producer3, (void *)thd5); 
  //  pthread_create(&thread_cons3, NULL, consumer3, (void *)thd6); 

    pthread_exit(NULL);

	return 0;
}
