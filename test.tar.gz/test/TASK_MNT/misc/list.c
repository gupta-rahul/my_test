#include<stdio.h>
#include<stdlib.h>
#include<dirent.h>
#include<string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

char *type(char typ)
{
	switch(typ) {
	
	case DT_BLK :	return "block device.";
		break;

	case DT_CHR : 	return "character device.";
		break;

	case DT_DIR :	return "directory.";
		break;

	case DT_FIFO : 	return "named pipe (FIFO).";
		break;

	case DT_LNK :	return  "symbolic link.";
		break;

	case DT_REG :	return "regular file.";
		break;

	case DT_SOCK : 	return "UNIX domain socket.";
		break;

	case DT_UNKNOWN:return "unknown.";
		break;
	}
}

int main(int argc, char *argv[])
{

	DIR *dir_ptr;
	struct dirent *dp;
	struct stat stat_buff;	
	dir_ptr = opendir(argv[1]);
	
	printf("\nListing......:-   %s\n", argv[1]);	
	printf("\nName\t\t\t Type\t\tSize\n");
	while ((dp = readdir(dir_ptr)) != NULL) {
		stat(dp->d_name, &stat_buff);
		printf("%-20s\t %s\t%d\n",dp->d_name, type(dp->d_type), stat_buff.st_size);
	}

	closedir(dir_ptr);
	return 0;
}
