#include<stdio.h>
#include<stdlib.h>


int main(void)
{
	int res;

	res = fork();
	
	if(res) 
	{
		wait(NULL);
		getchar();
		printf("This is Parent\n");
	} else {
		printf("This is Child\n");
	}	
	
	return 0;
}
