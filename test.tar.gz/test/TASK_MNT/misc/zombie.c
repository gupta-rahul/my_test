#include<stdio.h>
#include<stdlib.h>


int main(void)
{
	int res;
	printf("Main:- %d\n", getpid());

	if(fork()) 
	{
		printf("pid:- %d\n",getpid());
	//	wait(NULL);
		getchar();
		printf("This is Parent\n");
	} else {
		printf("This is Child\n");
		printf("child pid:- %d\n",getpid());
	}	
	
	return 0;
}
