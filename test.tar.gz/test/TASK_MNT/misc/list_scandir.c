#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	int res;
	DIR *dir_ptr;
	struct dirent **dp;
	struct stat stat_buff;	
	dir_ptr = opendir(argv[1]);
	
	res = scandir(dir_ptr,&dp,NULL,alphasort);

	printf("\nListing......:-   %s\n", argv[1]);	
	printf("\nName\t\t\t Type\t\tSize\n");

	closedir(dir_ptr);
	return 0;
}
