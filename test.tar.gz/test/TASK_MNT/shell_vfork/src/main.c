#include<shell.h>
#include <unistd.h>

void token(char *input, char **output);

int main(int argc, char *argv[])
{
	char input1[50];
	char *output[20]; 
	
	int res;
	while(1) {	
	res = vfork();
	if(res) {
	//	wait(NULL);	
	} else {
		printf("$-> ");
		fgets(input1, SIZE, stdin);
		token(input1, output);
		execvp(*output,output);
	}
	}
	return 0;
}

void token(char *input, char **output)
{
	*output++ = input;
	while (*input != '\0') {
		if (*input == ' ') {
			*input++ = '\0';
			*output++ = input;
		} else if (*input == '\n') {
			*input = '\0';
		} else
			input++;
	}
	*output = '\0';

}
