#ifndef _SHELL_H_
#define _SHELL_H_

#include<stdio.h>
#include<stdlib.h>

#define SIZE 50
  
#endif
