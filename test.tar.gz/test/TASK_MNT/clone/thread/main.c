# include <stdio.h>
# include <string.h>
# include <unistd.h>
# include <sched.h>
# include <linux/sched.h>
# include <signal.h>
# include <stdlib.h>
# include <sys/types.h>
# include <sys/syscall.h>
# define _GNU_SOURCE
#define STACK (1024 * 1024)

void fun(int x)
{
	printf("X :- %d\n", x);
	printf("pid:- %d\n", getpid());
	printf("tgid- %lu\n", syscall(SYS_gettid));
}

int main(void)
{
	int res;
		
	void *stack = malloc(STACK);
	
	void *stack_top = stack + STACK;

	res = clone(fun, stack_top, CLONE_VM | CLONE_FILES | CLONE_FS | CLONE_THREAD | CLONE_SIGHAND , 100);
	
	perror("res");
		if (res < 0)
		printf("Failed..\n");
}
