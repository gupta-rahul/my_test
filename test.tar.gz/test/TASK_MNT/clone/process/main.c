# include <stdio.h>
# include <linux/sched.h>
# include <signal.h>
# include <stdlib.h>
#define _GNU_SOURCE         /* See feature_test_macros(7) */
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/types.h>
void fun(int x)
{
	printf("PID:- %d\t TID :- %lu\n", getpid(), syscall(SYS_gettid));
}

int main(void)
{
	int res;
		
	void *stack = malloc(sizeof(char)*1024*1024);

	res = clone(fun, stack + 1024 * 1024,SIGCHLD, 100);

}
