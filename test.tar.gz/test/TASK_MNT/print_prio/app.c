#include<stdio.h>
#include<fcntl.h>
#include<linux/ioctl.h>


int main(void)
{
 	int fd;

         fd = open("/dev/char_dd", O_RDWR);
         if(fd < 0)
                 perror("Unable to open the device");
         else
                printf("File open successful : - %d\n", fd);

	 if (fork()) {
		 
	 	if (ioctl(fd, getpid()) == -1) {
      	 	perror("query_apps ioctl get");
		printf("parent :- %d\n", getpid());
		}
//		exit(1);
				
	} else {	
	 	if (ioctl(fd, getpid()) == -1) {
      	 	perror("query_apps ioctl get");
		printf("child :- %d\n", getpid());
		sleep(2);
	 }
	 }
	         close(fd);

         return 0;
}
