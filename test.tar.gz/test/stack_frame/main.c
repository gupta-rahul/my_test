#include<stdio.h>
#include<stdlib.h>

extern fun_1(void);

extern fun_2(void);

int main(void)
{

    int aa = 250;

    int bb = 1250;

    printf("sum of two Number is:- %d\n", aa + bb);

    fun_1();

    fun_2();

    printf("Making Main to Wait ....\n");

    getchar();

    return 0;
}   
