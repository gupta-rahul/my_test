#include<stdio.h>
#include<stdlib.h>


int main(int argc, char *argv[])
{

    unsigned int *ptr;

    ptr = 0xbffff0c8; 
    
    while(1) {

        printf(":- %d\n", ptr++);

        getchar();
    }


    return 0;

}
