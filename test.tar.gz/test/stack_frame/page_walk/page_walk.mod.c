#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x78a8cdd1, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x7485e15e, __VMLINUX_SYMBOL_STR(unregister_chrdev_region) },
	{ 0xa9382d64, __VMLINUX_SYMBOL_STR(cdev_del) },
	{ 0xb4abafd1, __VMLINUX_SYMBOL_STR(class_destroy) },
	{ 0x7bc8b586, __VMLINUX_SYMBOL_STR(device_destroy) },
	{ 0x2be7c454, __VMLINUX_SYMBOL_STR(device_create) },
	{ 0x307eb3d4, __VMLINUX_SYMBOL_STR(__class_create) },
	{ 0x610e0474, __VMLINUX_SYMBOL_STR(cdev_add) },
	{ 0x950a86e4, __VMLINUX_SYMBOL_STR(cdev_init) },
	{ 0x7a4686cd, __VMLINUX_SYMBOL_STR(cdev_alloc) },
	{ 0x29537c9e, __VMLINUX_SYMBOL_STR(alloc_chrdev_region) },
	{ 0xd1f54589, __VMLINUX_SYMBOL_STR(kmap) },
	{ 0xd5e63aa7, __VMLINUX_SYMBOL_STR(mem_map) },
	{ 0xf8bec4c5, __VMLINUX_SYMBOL_STR(pid_task) },
	{ 0xacf0857a, __VMLINUX_SYMBOL_STR(find_get_pid) },
	{ 0x50eedeb8, __VMLINUX_SYMBOL_STR(printk) },
	{ 0xb4390f9a, __VMLINUX_SYMBOL_STR(mcount) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "D48735DAFA9D07F95239E9D");
