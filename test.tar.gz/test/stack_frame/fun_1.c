#include<stdio.h>


void fun_1(void)
{

    int i = 0;


    for ( i = 0 ; i < 5; i++) {

    printf("This is Fun1 Function\n");

    }
}
