#include<stdio.h>


void fun_2(void)
{

    int i = 0;


    for ( i = 0 ; i < 5; i++) {

    printf("This is Fun2 Function\n");

    }
}
