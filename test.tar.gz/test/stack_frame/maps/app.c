#include<stdio.h>
#include<fcntl.h>
#include<linux/ioctl.h>
int main(void)
{

  int fd;
        char uBuffer[100];// = "character_device_driver";

         fd = open("/dev/char_dd", O_RDWR);
         if(fd < 0)
                 perror("Unable to open the device");
         else
                printf("File open successful : - %d\n", fd);
 
         printf("App Pid:- %d\n", getpid());

	if (ioctl(fd, getpid(), 0xbffff0c8) == -1) {
      	perror("query_apps ioctl get");
	}

         close(fd);

         return 0;
}
