#include<stdlib.h>
#include<signal.h>
#include<stdio.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <mqueue.h>
#define MAXMSG 1024 
#define MSGSIZE 4096 
#define FLAG 0

void fun()
{
    printf("Fun Funtion is called..\n");
}

int main(void)
{
    int i = 0;
    mqd_t msg_des;
    struct mq_attr msg_attr;
    char *mqname = "/my_mq";    
    size_t msg_len = 8192;
    unsigned msg_prio = 0;
    char msg_ptr[MSGSIZE];
    struct timespec abs_timeout;
    struct sigevent sevp;
    
    abs_timeout.tv_sec = 10;
//    abs_timeout.tv_nsec = 5;
//    
    int ret_stat;
/*
    sevp.sigev_notify = SIGEV_THREAD;
    sevp.sigev_signo = SIGUSR1; 
    sevp.sigev_notify_function = fun;
*/
    printf("Message Queue Attribute.\n");
    printf("mq_flags    :- %lu\n", msg_attr.mq_flags);       /* Flags: 0 or O_NONBLOCK */
    printf("mq_maxmsg   :- %lu\n", msg_attr.mq_maxmsg);      /* Max. # of messages on queue */
    printf("mq_msgsize  :- %lu\n", msg_attr.mq_msgsize);     /* Max. message size (bytes) */
    printf("mq_curmsgs  :- %lu\n", msg_attr.mq_curmsgs);     /* # of messages currently in queue */

    msg_attr.mq_flags = FLAG;
    msg_attr.mq_maxmsg = MSGSIZE;
    msg_attr.mq_msgsize = MAXMSG;
    
    /*Message Queue Opening or Creating */ 
    msg_des = mq_open(mqname, O_RDWR| O_CREAT, 0666, NULL);//&msg_attr);
     
    if (msg_des < 0)
            printf("Message open Failed in Receive  Operation....\n");
 
    printf("Message Queue Attribute.\n");
    printf("mq_flags    :- %lu\n", msg_attr.mq_flags);       /* Flags: 0 or O_NONBLOCK */
    printf("mq_maxmsg   :- %lu\n", msg_attr.mq_maxmsg);      /* Max. # of messages on queue */
    printf("mq_msgsize  :- %lu\n", msg_attr.mq_msgsize);     /* Max. message size (bytes) */
    printf("mq_curmsgs  :- %lu\n", msg_attr.mq_curmsgs);     /* # of messages currently in queue */
    
    /* Receving Message from Messge Queue*/ 
    while (1) {
        ret_stat = mq_receive(msg_des, msg_ptr, msg_len, &msg_prio);
        //ret_stat = mq_timedreceive(msg_des, msg_ptr, msg_len, &msg_prio, &abs_timeout);
  //      mq_notify(msg_des, &sevp);
        i++;
        sleep(1);
        if (ret_stat < 0)
            printf("Message Receing failed...\n"); 

        printf("\nMessage after Receving:-  %s\n", msg_ptr);
        if (i == 3)
            i = 0;
    }
    return 0;
}
