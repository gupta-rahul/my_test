#include<stdlib.h>
#include<stdio.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <mqueue.h>
#define MAXMSG 1024 
#define MSGSIZE 4096
#define FLAG 0

int main(void)
{
    int i;
    mqd_t msg_des;
    struct mq_attr msg_attr;
    char *mqname = "/my_mq";    
    size_t msg_len = 32;
    unsigned msg_prio = 0;
    char *msg_ptr[5] = {"process1","Process2", "Process3", "Process4", "process5"};
    int ret_stat;
 
    printf("Message Queue Attribute.\n");
    printf("mq_flags    :- %lu\n", msg_attr.mq_flags);       /* Flags: 0 or O_NONBLOCK */
    printf("mq_maxmsg   :- %lu\n", msg_attr.mq_maxmsg);      /* Max. # of messages on queue */
    printf("mq_msgsize  :- %lu\n", msg_attr.mq_msgsize);     /* Max. message size (bytes) */
    printf("mq_curmsgs  :- %lu\n", msg_attr.mq_curmsgs);     /* # of messages currently in queue */

    msg_attr.mq_flags = FLAG;
    msg_attr.mq_maxmsg = MSGSIZE;
    msg_attr.mq_msgsize = MAXMSG;
    msg_attr.mq_curmsgs = 0;
    
    mq_setattr(msg_des, &msg_attr,NULL);
    
    /*Opeing or Creating the Message Queue */    
    msg_des = mq_open(mqname, O_RDWR | O_CREAT , 0666, &msg_attr);

    if (msg_des < 0)
            printf("Message open Failed in send Operation....\n");

    printf("Message Queue Attribute.\n");
    printf("mq_flags    :- %lu\n", msg_attr.mq_flags);       /* Flags: 0 or O_NONBLOCK */
    printf("mq_maxmsg   :- %lu\n", msg_attr.mq_maxmsg);      /* Max. # of messages on queue */
    printf("mq_msgsize  :- %lu\n", msg_attr.mq_msgsize);     /* Max. message size (bytes) */
    printf("mq_curmsgs  :- %lu\n", msg_attr.mq_curmsgs);     /* # of messages currently in queue */
    
    i = 0;

    /*Sending the  Message in Message Queue */
    while(1) {
        ret_stat = mq_send(msg_des, msg_ptr[i], msg_len, msg_prio);
        i++;
        sleep(1);
        if (ret_stat < 0)
            printf("Message Sending Failed...\n");
        if (i == 5)
            i = 0;
    }

    return 0;
}
