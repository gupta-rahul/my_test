#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <sys/mman.h>
#include <sys/stat.h>        /* For mode constants */
#include <fcntl.h>           /* For O_* constants */
#include <unistd.h>
#include <sys/types.h>
#define MAXSIZE 4096

int main(void)
{
    int i;

    int shm_fd;
    
    int ret_ftruncate;
    
    void *shm_addr;

    void *write_ptr;

    char *shm_name = "/critical_section";
    
    /* Creating or Opening Shared Memory */
    shm_fd = shm_open(shm_name, O_RDWR | O_CREAT, 0666);

    if (shm_fd == -1)
            printf("Shared Memory Allocation Failed in Write Operation..\n");

    /* Initializing the Size of the shared Memory */
    ret_ftruncate = ftruncate(shm_fd, MAXSIZE);

    if (ret_ftruncate == -1)
            printf("Truncating failed in Write...\n");

    /* Maping of Shared Memory*/
    shm_addr = mmap(0,MAXSIZE, PROT_WRITE | PROT_READ,  MAP_SHARED, shm_fd, 0);

    if (shm_addr == NULL)
            printf("Mapping Failed ...\n");
    else 
            printf("Shm_address:;- %p\n", shm_addr);

    write_ptr = (int *)shm_addr;

    /* Writing to the Shared Memory */
    for (i = 0; i < (MAXSIZE / 4); i++) {
        *(int *)write_ptr = i + 1;
        write_ptr += 4;
    }
    
    /*Closing */
    close(shm_fd);

    return 0;
}
