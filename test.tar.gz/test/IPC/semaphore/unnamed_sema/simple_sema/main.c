#include<stdio.h>
#include<stdlib.h>
#include<semaphore.h>
#include<unistd.h>
#include<pthread.h>

int critical_section;
sem_t sem_lock;
int pshared = 0;
unsigned int value = 1;
int sem_val1;
int sem_val2;

void *cs_access1(void *ptr )
{
    int i = 0;
    printf("cs_access1......\n");
    sem_getvalue(&sem_lock, &sem_val1);
    printf("Present Value of semaphore In Thread 1 before Acquiring Lock:- %d\n", sem_val1);
   
    if (!sem_wait(&sem_lock)) {
        sem_getvalue(&sem_lock, &sem_val1);
        printf("Present Value of semaphore In Thread 1 after Acquiring Lock:- %d\n", sem_val1);
        critical_section = 11;
        printf("cs_access 1 critical_section:- %d\n", critical_section);
        
        while(i != 5) {
            printf("Semaphore Acqured by thread 1 ..%d..\n", ++critical_section);
            ++i;
            sleep(1);
        }
        
        if (!sem_post(&sem_lock))
              printf("Semaphore Released by Thread 1\n");
    } else {
        printf("Semaphore Locking failed by Thread 1...\n");
    }
}

void *cs_access2(void *ptr)
{
    int i = 0;
    printf("cs_access2.......\n");
    sem_getvalue(&sem_lock, &sem_val2);
    printf("Present Value of semaphore In Thread 2 before Acquiring Lock:- %d\n", sem_val2);
    
    if (!sem_wait(&sem_lock)) {
        sem_getvalue(&sem_lock, &sem_val2);
        printf("Present Value of semaphore In Thread 2 after Acquiring Lock:- %d\n", sem_val2);
        printf("Semaphore Acquired by Thread 2....\n");
        critical_section = 22;
        printf("cs_access 2 critical_section:- %d\n", critical_section);
      
        while(i != 5) {
            printf("Semaphore Acqured by thread 2 ..%d..\n",--critical_section);
            ++i;
            sleep(1);
        }
      
        if (!sem_post(&sem_lock))
                printf("Semaphore Released by Thread 2\n");
    } else {
        printf("Semaphore Locking failed by Thread 2...\n");
    }
}

int main()
{
    int ret_state;
    pthread_t thread1;
    pthread_t thread2;

    ret_state = sem_init(&sem_lock, pshared, value);
    
    pthread_create(&thread1,NULL, cs_access1, NULL);
    pthread_create(&thread2,NULL, cs_access2, NULL);

    if (ret_state < 0)
        printf("Initialization failed...\n");

    pthread_exit(NULL);
    return 0;
}
