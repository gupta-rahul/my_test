#include<stdio.h>
#include<stdlib.h>
#include<semaphore.h>
#include<unistd.h>
#include<pthread.h>
#define MAX 8

int critical_section;
sem_t empty;
sem_t full;
int pshared = 0;
unsigned int value = 0;
int sem_val1;
int sem_val2;

int buffer[MAX];
int fill = 0;
int use = 0;

void put(int value)
{
    buffer[fill] = value;
    fill = (fill + 1) % MAX;
}

int get()
{
    int temp = buffer[use];
    use = (use + 1) % MAX;
    return temp;
}

void *producer(void *ptr)
{
    int i = 0;
    for (i = 0; i < 8; i++) {
        sem_wait(&empty);
        put(i);
        sleep(1);
        sem_post(&full);
    } 
}

void *producer2(void *ptr)
{
    int i = 0;
    for (i = 0; i < 8; i++) {
        sem_wait(&empty);
        put(11);
        sleep(1);
        sem_post(&full);
    } 
}

void *consumer(void *ptr)
{
    int i;
    int tmp;
    while (tmp != 7) {
        sem_wait(&full);
        tmp = get();
        sem_post(&empty);
        printf("%d\n", tmp);
    }

}

int main()
{
    int ret_state;
    pthread_t thread1;
    pthread_t thread2;
    pthread_t thread3;
    pthread_t thread4;

    if (sem_init(&full, pshared, 0) < 0)
            printf("Semaphore Initialization Failed....\n");
    
    if (sem_init(&empty, pshared, MAX) < 0)
            printf("Semaphore Initialization Failed....\n");
    
    pthread_create(&thread2,NULL, consumer, NULL);
    pthread_create(&thread1,NULL, producer, NULL);
    pthread_create(&thread3,NULL, consumer, NULL);
    pthread_create(&thread4,NULL, producer2, NULL);

    pthread_exit(NULL);
    return 0;
}
