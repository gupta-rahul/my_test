#include<stdio.h>
#include<stdlib.h>
#include<semaphore.h>
#include<unistd.h>
#include<pthread.h>

int critical_section;
sem_t sem_lock;
int pshared = 0;
unsigned int value = 0;
int sem_val1;
int sem_val2;

void *cs_access1(void *ptr )
{
    int i = 0;
    sem_getvalue(&sem_lock, &sem_val1);
    printf("Present Value of semaphore In Thread 1 before Acquiring Lock:- %d\n", sem_val1);
    printf("Thread 1 CAlling Function......\n");
    sem_post(&sem_lock);
    sem_getvalue(&sem_lock, &sem_val1);
    printf("Present Value of semaphore In Thread 1 before Acquiring Lock:- %d\n", sem_val1);
  
}

int main()
{
    int ret_state;
    pthread_t thread1;

    if (sem_init(&sem_lock, pshared, value < 0))
            printf("Semaphore Initialization Failed....\n");
    
    pthread_create(&thread1,NULL, cs_access1, NULL);
    sem_wait(&sem_lock);
    printf("Thread Execution Finished...\n");

    pthread_exit(NULL);
    return 0;
}
