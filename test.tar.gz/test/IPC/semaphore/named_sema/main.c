#include<stdio.h>
#include<stdlib.h>
#include<semaphore.h>
#include<unistd.h>
#include<pthread.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */

int critical_section;
sem_t sem_lock;
unsigned int value = 1;

/*
void *cs_access1(void *ptr )
{
    int i = 0;
    printf("cs_access1......\n");
    sem_getvalue(&sem_lock, &sem_val1);
    printf("Present Value of semaphore In Thread 1 before Acquiring Lock:- %d\n", sem_val1);
   
    if (!sem_wait(&sem_lock)) {
        sem_getvalue(&sem_lock, &sem_val1);
        printf("Present Value of semaphore In Thread 1 after Acquiring Lock:- %d\n", sem_val1);
        critical_section = 11;
        printf("cs_access 1 critical_section:- %d\n", critical_section);
        
        while(i != 5) {
            printf("Semaphore Acqured by thread 1 ..%d..\n", ++critical_section);
            ++i;
            sleep(1);
        }
        
        if (!sem_post(&sem_lock))
              printf("Semaphore Released by Thread 1\n");
    } else {
        printf("Semaphore Locking failed by Thread 1...\n");
    }
}

void *cs_access2(void *ptr)
{
    int i = 0;
    printf("cs_access2.......\n");
    sem_getvalue(&sem_lock, &sem_val2);
    printf("Present Value of semaphore In Thread 2 before Acquiring Lock:- %d\n", sem_val2);
    
    if (!sem_wait(&sem_lock)) {
        sem_getvalue(&sem_lock, &sem_val2);
        printf("Present Value of semaphore In Thread 2 after Acquiring Lock:- %d\n", sem_val2);
        printf("Semaphore Acquired by Thread 2....\n");
        critical_section = 22;
        printf("cs_access 2 critical_section:- %d\n", critical_section);
      
        while(i != 5) {
            printf("Semaphore Acqured by thread 2 ..%d..\n",--critical_section);
            ++i;
            sleep(1);
        }
      
        if (!sem_post(&sem_lock))
                printf("Semaphore Released by Thread 2\n");
    } else {
        printf("Semaphore Locking failed by Thread 2...\n");
    }
}
*/

int main()
{
    sem_t *ret_state;
    pthread_t thread1;
    pthread_t thread2;
    char *sem_name = "/sema";

    ret_state = sem_open(sem_name, O_CREAT , 0666, value);
    
    if (ret_state == SEM_FAILED)
            printf("Semaphore Acquired Failed...\n");


    //  pthread_create(&thread1,NULL, cs_access1, NULL);
  //  pthread_create(&thread2,NULL, cs_access2, NULL);

    pthread_exit(NULL);
    return 0;
}
