/*
	Funtion for Displaying AVL tree in preorder
*/

#include<avl.h>

int display_preorder(struct avl **root)
{

	struct avl *temp_ptr = NULL;			/* pointer of Struct avl type */
	
	if (*root == NULL) {
		return 0;
	}
	
	temp_ptr = *root;
	printf("Item:- %d  right:-  %p    left:- %p\n", temp_ptr->info, temp_ptr->right_child, temp_ptr->left_child);
	display_preorder(&temp_ptr->left_child);
	display_preorder(&temp_ptr->right_child);
	
	return 0;
}
