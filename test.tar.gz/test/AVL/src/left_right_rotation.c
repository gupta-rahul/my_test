/*
	Function for left right rotation 
*/

#include<avl.h>

void left_right_rotation(struct avl **root)
{

        printf("Left right Rotataion is getting Called \n");

        if (*root != NULL) {
                printf("in left right rotation call  - %p\n", *root);
                right_rotation(&(*root)->left_child);
                left_rotation(root);
        }





}


