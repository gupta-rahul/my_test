/*
	Funtion for Display operation
*/

#include<avl.h>

int display_option(struct avl **root)
{
	int choice;			/* int variable for Choice */
	
	while (1) {
		printf("\nEnter Choice\n");
		printf("1. Display AVL in Inorder\n");
		printf("2. Display AVL in Preorder\n");
		printf("3. Display AVL in Postorder\n");
		printf("4. Return to Main Menu\n");
		printf("5. Exit\n");
		scanf("%d", &choice);

	switch(choice) {
	
	case 1:	display_inorder(root);
		break;

	case 2:	display_preorder(root);
		break;
	
	case 3:	display_postorder(root);
		break;

	case 4:	return 0;

	case 5:	exit(1);

	}

	}

	return 0;

}
