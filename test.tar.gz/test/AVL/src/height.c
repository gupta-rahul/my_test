/*
	Function for finding height of a node 
*/

#include<avl.h>

int height(struct avl **root)
{
	struct avl **temp = NULL;	/* pointer of avl type */
		
	int right_ht = 0;		/* int variable for height of right subtree */
	int left_ht = 0;		/* int variable for height of left subtree */
	
	temp = root;

	if (*temp == NULL)
		return 0;

	left_ht = height(&(*temp)->left_child);
		
	right_ht = height(&(*temp)->right_child);

	if (right_ht > left_ht)
		return right_ht + 1;
	else
		return left_ht + 1;
}
