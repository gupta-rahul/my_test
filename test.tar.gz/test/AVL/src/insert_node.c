/*
	Funtion for Inserting Node in AVL Search tree
*/

#include<avl.h>

int insert_node(struct avl **root, int item)
{

	struct avl **temp = NULL;			/* pointer of Struct avl type */
	struct avl *temp_avl = NULL;			/* pointer of Struct avl type */
	int bf = 0;
	
	temp = root;

        if (*temp == NULL) {
		/* Memory Allocation */
		if ((temp_avl = (struct avl *)malloc(sizeof(struct avl))) == NULL)
			printf("---->Memory Allocation faile in Create_avl funtion\n");
		/* getting the node Value */
		printf("Address of new Node:- %p\n", temp_avl);
		temp_avl->info = item;
		temp_avl->left_child = NULL;
	        temp_avl->right_child = NULL;
		*root = temp_avl;
	} else if ((*temp)->info > item) {
		insert_node((&(*temp)->left_child), item);
	        bf = bal_factor(root);
		printf("Address of Root:- %p\n", *root);
	        if (bf > 1 ) {
			if (bal_factor(&(*root)->left_child) > 0)
	        		left_rotation(root);
			else
				left_right_rotation(root);
		}
	} else {
		insert_node((&(*temp)->right_child), item);
		bf = bal_factor(root);
                if (bf < -1 ) {
                        if (bal_factor(&(*root)->right_child) > 0)
				right_left_rotation(root);
			else
				right_rotation(root);
		}
	}
	return 0;
}
