/*
	Funtion for Displaying AVL tree in preorder
*/

#include<avl.h>

int display_inorder(struct avl **root)
{

	struct avl *temp_ptr = NULL;			/* pointer of Struct avl type */
	
	if (*root == NULL) {
		return 0;
	}
	
	temp_ptr = *root;
	display_inorder(&temp_ptr->left_child);
	printf("Item:- %d  right:-  %p    left:- %p\n", temp_ptr->info, temp_ptr->right_child, temp_ptr->left_child);
	display_inorder(&temp_ptr->right_child);
	
	return 0;
}
