/*
	Main Function
*/

#include<avl.h>

int main(void)
{
        struct avl *root = NULL;

        int choice = 0;	
	int item;

        while (1) {
        printf("\t A-V-L Tree\n");
        printf("1. Insert operations in AVL\n");
        printf("2. Heightof node in AVL\n");
        printf("3. Balance Factor of Value in AVL\n");
        printf("4. Display operationsin AVL\n");
	printf("5. Exit \n");
        printf("Enter Choice\n");

        scanf("%d", &choice);

        switch(choice) {

        case 1:	printf("Enter the item\n");
		scanf("%d", &item);
		insert_node(&root, item);
                break;

        case 2:	printf("height:- %d\n",height(&root));
                break;

        case 3:	get_node_bf(&root);
                break;

	case 4:	display_option(&root);
                break;

        case 5: exit(1);
	
	
	}

	}

	return 0;

}
