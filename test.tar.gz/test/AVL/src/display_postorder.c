/*
	Funtion for Displaying AVL  tree in postorder
*/

#include<avl.h>

int display_postorder(struct avl **root)
{

	struct avl *temp_ptr = NULL;			/* pointer of Struct avl type */
	
	if (*root == NULL) {
		return 0;
	}
	
	temp_ptr = *root;
		
	display_postorder(&temp_ptr->left_child);
	display_postorder(&temp_ptr->right_child);
	printf("Item:- %d\n", temp_ptr->info);
	return 0;
}
