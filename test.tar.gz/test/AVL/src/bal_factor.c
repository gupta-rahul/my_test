/*
	Function for finding the Balance Factor of a node 
*/

#include<avl.h>


int bal_factor(struct avl **node)
{
	int bf = 0;			/* int variable for balance factor */
	int left_stree = 0;		/* int variable for left subtre balance factor */
	int right_stree = 0;		/* int variable for right subtre balance factor*/

	left_stree = height(&(*node)->left_child);
	right_stree = height(&(*node)->right_child);

	bf = left_stree - right_stree;

	return bf;
}
