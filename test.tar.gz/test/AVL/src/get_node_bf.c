/*
	Function for getting balance factor of a Node 
*/

#include<avl.h>

int get_node_bf(struct avl **node)
{

	int temp_node;				/* int variable for temp node */
	struct avl *temp_ptr = NULL;		/* pointer of struct avl type */

	int bf =0 ;				/* int variable for balance factor */
	
	printf("Enter the value whose bf is to find\n");
	scanf("%d", &temp_node);

	temp_ptr = *node;

	while (temp_ptr != NULL) {
		if (temp_ptr->info > temp_node)
			temp_ptr = temp_ptr->left_child;
		else if (temp_ptr->info < temp_node)
			temp_ptr = temp_ptr->right_child;
		else
			break;

	}

	bf = bal_factor(&temp_ptr);
	printf("Balance Factor of value :- %d\n", bf);
	return bf;
}
