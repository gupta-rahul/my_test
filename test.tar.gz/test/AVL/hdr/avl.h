#ifndef _AVL_H_
#define _AVL_H_

#include<stdio.h>
#include<stdlib.h>

struct avl {					/* AVL Structure */
	struct avl *left_child;
	struct avl *right_child;
	int info;
};

int insert_node(struct avl **root, int item);   /* Function for Inserting the node in AVL*/

int display_inorder(struct avl **root);         /* Function for Displaying AVL in Inorder */

int display_preorder(struct avl **root);        /* Function for Displaying AVL in Preorder */

int display_postorder(struct avl **root);        /* Function for Displaying AVL in Postorder */

int display_option(struct avl **root);          /* Function for Display Option */

int bal_factor(struct avl **node);		/* Function for getting Balance factor */

int get_node_bf(struct avl **node);		/* Function for getting balance factor of a node */

void right_rotation(struct avl **root);		/* Function for Right Rotation for Balancing AVL Tree */

void left_rotation(struct avl **root);		/* Function for Left Rotation for Balancing AVL Tree */

void left_right_rotation(struct avl **root);	/* Function for Left Right Rotation for Balancing AVL Tree*/

void right_left_rotation(struct avl **root);	/* Function for Right Left Rotation for Balancing AVL Tree*/

int height(struct avl **root);			/* Function for getting height of Root */
#endif
