#include <stdio.h>
#include<unistd.h>

	int main()

	{

	        pid_t pid;
		int i;

	        pid = vfork();

	        switch(pid)

	        {

	                case -1: /* an error occurred */

	                     printf("Fork error");

	                     break;

	                case 0: /* this code is executed by the child process */

	                     for(i=1; i<10; i++)

                             printf("Child process, iteration: %d\n", i);
	                     break;

	                default: /* this code is executed by the parent process */

	                     for(i=1; i<10; i++)

	                             printf("Parent process, iteration: %d\n", i);

	        }

	}
