#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>

int main()
{
	int res;
	
	if (vfork()) {
		printf("Parent...");
		exit();
	} else {
	
		printf("child..");
	}
	
}
