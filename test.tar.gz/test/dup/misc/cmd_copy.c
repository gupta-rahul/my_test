#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void cmd_cpy(char *cmd)
{
    FILE *fd;

    printf("cmd_cpy:- %s\n", cmd);

    fd = fopen("com_hist.txt", "a+");

    perror("In cmd:fopen");

    fwrite(cmd, strlen(cmd), 1,fd);

    perror("fwrite");

    fclose(fd);
}
