#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>


int main(int argc, char *argv[])
{
    int status;

    char *ptr[10];

    char *string1 = (char *)malloc(sizeof(char) * 256);
    
    char *str_delim = NULL;

    while (1) {
        if (fork()) {
            wait(&status);
        } else {
            
            get_string(ptr, string1, str_delim);

            execvp(ptr[0], ptr);

            perror("execvp");
        }
    }
    return 0;
}
