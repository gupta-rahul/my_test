#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void com_hist(char *string1)
{
    FILE * fd;

    char c;

    int size;

    int count = 0;

    int number;

    fd = fopen("com_hist.txt", "r");

    perror("In com_hist fopen");

    while ((c = getc(fd)) != EOF)
            putc(c, stdout);

    rewind(fd);

    printf("Enter the Command No:- ");

    scanf("%d", &number);

    while (number > count++) {
        //printf("fread :- %d\n",fread(string1, 256,1 , fd));//fgets(string1, 256, fd);
        getline(&string1, &size, fd);
        printf("string:- %s\n", string1);
        perror("fread");
    }


        printf("com_hist string:- %s\n", string1);

        fclose(fd);
}
