#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

void get_string(char **ptr, char *string1, char *str_delim) 
{
    int i = 0;
    
    int count = 0;
    
    char *temp_ptr = NULL;
    
    char *str_copy = NULL;

    str_copy = (char *)malloc(sizeof(char) * 256);
    
    printf("Command$:- ");

    fgets(string1, 256, stdin);

    strcpy(str_copy, string1);
 
    cmd_cpy(str_copy);

    str_delim = " \n";

    printf("after cmd_cpy call\n");
hist:
    printf("label:string1:- %s\n", string1);

    temp_ptr = strtok(string1, str_delim);

    while (temp_ptr != NULL) {
        ptr[i++] = temp_ptr;    
        temp_ptr = strtok(NULL, str_delim);
        ++count;
    }

    printf("prt0 :- %s\n", ptr[0]);
    ptr[i] = NULL;
    
    printf("prt0 :- %s\n", ptr[0]);
    
    if (!strcmp(ptr[0], "w") || !strcmp(ptr[0], "s")) {

        com_hist(string1);
        goto hist;
    }
}
