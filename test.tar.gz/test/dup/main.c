#include <fcntl.h>              /* Obtain O_* constant definitions */
#include <unistd.h>
#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
    int fd;
    int fd1;
    int fd2;
    int result;
    char c;

    if ((!strcmp(argv[1], ">>")) || (!strcmp(argv[1], ">"))) {
        if (!strcmp(argv[1], ">>"))                                     /* Appening to file from Command line */
            fd = open( argv[2], O_CREAT| O_RDWR | O_APPEND,  0666);
        else 
            fd = open( argv[2], O_CREAT| O_RDWR | O_TRUNC,  0666);      /* Copying to file from Command line */

        close(1);

        dup(fd);

        while ((c = getchar()) != EOF)
            putchar(c);
        
        close(fd);      /*closing fd*/
    
    } else if ((!strcmp(argv[2], ">>")) || (!strcmp(argv[2], ">"))){
        if (!strcmp(argv[2], ">>")) {                                   /* Appening to file from from file */
            fd2 = open( argv[3], O_CREAT| O_RDWR | O_APPEND,  0666);
        } else {
            fd2 = open( argv[3], O_CREAT| O_RDWR | O_TRUNC,  0666);     /* Copying to file from Command line */
        }

        fd1 = open( argv[1], O_CREAT| O_RDWR,  0666);               
        
        close(0);           /*close stdin */
        close(1);           /*close stdin */

        dup(fd1);
        dup(fd2);

        while ((c = getchar()) != EOF)
            putchar(c);

        close(fd1);     /*closing fd*/
        close(fd2);     /*closing fd*/
    }

    return 0;
}
